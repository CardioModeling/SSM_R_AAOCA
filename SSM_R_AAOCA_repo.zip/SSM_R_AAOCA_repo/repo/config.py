r"""
config.py — centralized I/O paths for the R-AAOCA SSM pipeline.

All scripts import their input/output directories from here instead of
hardcoding them. By default everything lives under ./data relative to
the repository root, but you can point the whole pipeline elsewhere by
setting the SSM_DATA_DIR environment variable, e.g.:

    export SSM_DATA_DIR=/path/to/my/dataset      # Linux/Mac
    set SSM_DATA_DIR=D:\my\dataset                # Windows

Folder layout created/expected under BASE_DIR:

    data/
      00_raw_nrrd/                       <- input segmented CTA volumes (.nrrd)
      01_aorta_preprocessed/             <- step 1  output
      02_rca_preprocessed/               <- step 2  output
      03_aorta_aligned_rigid/            <- step 3  output
      04_rca_aligned_rigid/              <- step 4  output
      05_normalized/
        aorta/{centerlines,masks}
        rca/{centerlines,masks,ostia}
      06_meshes/{aorta,rca}              <- step 6  output (mask -> mesh)
      07_remeshed/{aorta,rca}            <- step 7  output (uniform remesh)
      08_registered/{aorta,rca}          <- step 8  output (CPD registration)
      09_pca/{aorta,rca}                 <- step 9  output (SSM / PCA results)
      clinical/clinical_data.xlsx        <- clinical variables spreadsheet
"""

import os

BASE_DIR = os.environ.get(
    "SSM_DATA_DIR",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"),
)

# ---- step 0: raw input --------------------------------------------------
RAW_NRRD_DIR = os.path.join(BASE_DIR, "00_raw_nrrd")

# ---- step 1-2: preprocessing (segmentation -> centerline + cleaned mask) -
AORTA_PREPROCESSED_DIR = os.path.join(BASE_DIR, "01_aorta_preprocessed")
RCA_PREPROCESSED_DIR   = os.path.join(BASE_DIR, "02_rca_preprocessed")

# ---- step 3-4: rigid (Kabsch) alignment to a common template -------------
AORTA_ALIGNED_RIGID_DIR = os.path.join(BASE_DIR, "03_aorta_aligned_rigid")
RCA_ALIGNED_RIGID_DIR   = os.path.join(BASE_DIR, "04_rca_aligned_rigid")

# ---- step 5: arc-length normalization / clipping -------------------------
NORMALIZED_DIR       = os.path.join(BASE_DIR, "05_normalized")
NORM_AORTA_CL_DIR    = os.path.join(NORMALIZED_DIR, "aorta", "centerlines")
NORM_AORTA_MASK_DIR  = os.path.join(NORMALIZED_DIR, "aorta", "masks")
NORM_RCA_CL_DIR      = os.path.join(NORMALIZED_DIR, "rca", "centerlines")
NORM_RCA_MASK_DIR    = os.path.join(NORMALIZED_DIR, "rca", "masks")
NORM_RCA_OSTIA_DIR   = os.path.join(NORMALIZED_DIR, "rca", "ostia")

# ---- step 6: marching-cubes surface mesh + watertight repair -------------
MESH_DIR       = os.path.join(BASE_DIR, "06_meshes")
MESH_AORTA_DIR = os.path.join(MESH_DIR, "aorta")
MESH_RCA_DIR   = os.path.join(MESH_DIR, "rca")

# ---- step 7: uniform remeshing (ACVD) -------------------------------------
REMESH_DIR       = os.path.join(BASE_DIR, "07_remeshed")
REMESH_AORTA_DIR = os.path.join(REMESH_DIR, "aorta")
REMESH_RCA_DIR   = os.path.join(REMESH_DIR, "rca")

# ---- step 8: non-rigid (CPD) registration to the template ----------------
REGISTERED_DIR       = os.path.join(BASE_DIR, "08_registered")
REG_AORTA_DIR         = os.path.join(REGISTERED_DIR, "aorta")
REG_RCA_DIR           = os.path.join(REGISTERED_DIR, "rca")

# ---- step 9: PCA / statistical shape model + clinical correlations -------
PCA_DIR       = os.path.join(BASE_DIR, "09_pca")
PCA_AORTA_DIR = os.path.join(PCA_DIR, "aorta")
PCA_RCA_DIR   = os.path.join(PCA_DIR, "rca")

# ---- clinical data ----------------------------------------------------
CLINICAL_XLSX = os.path.join(BASE_DIR, "clinical", "clinical_data.xlsx")


def ensure_all_dirs():
    """Create every pipeline directory if it doesn't already exist."""
    for path in [
        RAW_NRRD_DIR,
        AORTA_PREPROCESSED_DIR, RCA_PREPROCESSED_DIR,
        AORTA_ALIGNED_RIGID_DIR, RCA_ALIGNED_RIGID_DIR,
        NORM_AORTA_CL_DIR, NORM_AORTA_MASK_DIR,
        NORM_RCA_CL_DIR, NORM_RCA_MASK_DIR, NORM_RCA_OSTIA_DIR,
        MESH_AORTA_DIR, MESH_RCA_DIR,
        REMESH_AORTA_DIR, REMESH_RCA_DIR,
        REG_AORTA_DIR, REG_RCA_DIR,
        PCA_AORTA_DIR, PCA_RCA_DIR,
        os.path.dirname(CLINICAL_XLSX),
    ]:
        os.makedirs(path, exist_ok=True)


if __name__ == "__main__":
    ensure_all_dirs()
    print(f"Pipeline data directory tree created under: {BASE_DIR}")
