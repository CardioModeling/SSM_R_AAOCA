import os
import numpy as np
import nrrd
import pyvista as pv
import networkx as nx

from scipy.ndimage import (
    binary_fill_holes,
    label as cc_label,
    distance_transform_edt,
)
from scipy.interpolate import splprep, splev
from skimage.morphology import ball, closing


import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RAW_NRRD_DIR, AORTA_PREPROCESSED_DIR  # noqa: E402

INPUT = RAW_NRRD_DIR
OUT   = AORTA_PREPROCESSED_DIR

os.makedirs(OUT, exist_ok=True)


# ======================================================
# NRRD GEOMETRY
# ======================================================
def nrrd_affine_from_header(hdr):
    origin = np.array(hdr.get("space origin", [0, 0, 0]), float)
    sd = hdr.get("space directions", None)

    if sd is None:
        sp = np.array(hdr.get("spacings", [1, 1, 1]), float)[:3]
        M = np.diag(sp)
        return origin, M

    cols = []
    for v in sd[:3]:
        if v is None:
            cols.append(np.array([0.0, 0.0, 0.0], float))
        else:
            cols.append(np.array(v, float))

    M = np.column_stack(cols)
    return origin, M


def voxel_to_phys(ijk, origin, M):
    ijk = np.asarray(ijk, float)
    return origin[None, :] + ijk @ M.T


def phys_to_voxel(xyz, origin, M):
    xyz = np.asarray(xyz, float)
    Minv = np.linalg.pinv(M)
    return (xyz - origin[None, :]) @ Minv.T


def spacing_from_M(M):
    return np.linalg.norm(M, axis=0)


def step_length_phys(delta, M):
    return float(np.linalg.norm(M @ delta.astype(float)))


# ======================================================
# SEGMENT EXTRACTION
# ======================================================
def find_segment_indices_in_header(hdr):
    idxs = set()
    for k in hdr.keys():
        if k.startswith("Segment") and "_" in k:
            s = k.split("_")[0].replace("Segment", "")
            if s.isdigit():
                idxs.add(int(s))
    return sorted(idxs)


def find_label_value_for_segment_name(hdr, segment_name, fallback=None):
    for i in find_segment_indices_in_header(hdr):
        name = hdr.get(f"Segment{i}_Name", "")
        if name == segment_name:
            return int(hdr.get(f"Segment{i}_LabelValue", i))
    return fallback


def extract_mask(data, hdr, segment_name, fallback_label):
    label_value = find_label_value_for_segment_name(hdr, segment_name, fallback=fallback_label)
    return (data == label_value)


# ======================================================
# MASK CLEANING
# ======================================================
def keep_largest_cc(mask):
    lab, n = cc_label(mask)
    if n == 0:
        return mask.astype(bool)

    sizes = np.bincount(lab.ravel())
    sizes[0] = 0
    return (lab == np.argmax(sizes))


def clean_mask(mask):
    mask = binary_fill_holes(mask)
    mask = closing(mask, ball(1))
    mask = keep_largest_cc(mask)
    return mask.astype(bool)


# ======================================================
# ENDPOINT SELECTION
# ======================================================
def choose_proximal_and_distal_points(aorta_mask, lv_mask, origin, M):
    """
    Proximal point:
      voxel dell'aorta più vicino al centroide del LV
    Distal point:
      voxel dell'aorta con coordinata fisica superiore massima
    """
    a_vox = np.argwhere(aorta_mask)
    if a_vox.size == 0:
        raise RuntimeError("Maschera aorta vuota")

    a_phys = voxel_to_phys(a_vox.astype(float), origin, M)

    lv_vox = np.argwhere(lv_mask)
    if lv_vox.size == 0:
        raise RuntimeError("Maschera LV vuota")

    lv_cent = voxel_to_phys(lv_vox.astype(float), origin, M).mean(axis=0)

    # prossimale = aorta voxel più vicino al LV
    d_lv = np.linalg.norm(a_phys - lv_cent[None, :], axis=1)
    prox_idx = int(np.argmin(d_lv))
    prox_vox = tuple(a_vox[prox_idx])

    # distale = voxel più superiore lungo asse S-I del volume fisico
    # uso coordinata fisica z come proxy
    dist_idx = int(np.argmax(a_phys[:, 2]))
    dist_vox = tuple(a_vox[dist_idx])

    return prox_vox, dist_vox


# ======================================================
# MINIMUM-COST PATH INSIDE MASK
# ======================================================
def build_mask_graph_with_center_preference(mask_bool, M):
    vox = np.argwhere(mask_bool)
    if vox.size == 0:
        raise RuntimeError("Maschera vuota")

    spacing = spacing_from_M(M)
    dist = distance_transform_edt(mask_bool, sampling=spacing)

    G = nx.Graph()

    dirs = [(i, j, k) for i in (-1, 0, 1)
                      for j in (-1, 0, 1)
                      for k in (-1, 0, 1)
                      if not (i == j == k == 0)]

    for v in vox:
        G.add_node(tuple(v))

    nodes = set(G.nodes)

    for x, y, z in nodes:
        d_here = float(dist[x, y, z])

        for dx, dy, dz in dirs:
            n = (x + dx, y + dy, z + dz)
            if n not in nodes:
                continue

            d_next = float(dist[n[0], n[1], n[2]])
            step_mm = step_length_phys(np.array([dx, dy, dz]), M)

            center_bonus = max(0.5 * (d_here + d_next), 1e-3)

            # costo basso se stai nel centro del vaso
            w = step_mm / center_bonus

            G.add_edge((x, y, z), n, weight=w)

    return G


def compute_centerline_vox_from_mask(mask_bool, lv_mask, origin, M):
    prox_vox, dist_vox = choose_proximal_and_distal_points(mask_bool, lv_mask, origin, M)
    G = build_mask_graph_with_center_preference(mask_bool, M)

    try:
        path = nx.shortest_path(G, prox_vox, dist_vox, weight="weight")
    except Exception as e:
        raise RuntimeError(f"Path non trovato: {e}")

    return np.array(path, dtype=float)


# ======================================================
# CENTERLINE POST-PROCESSING
# ======================================================
def polyline_arclength(cl_phys):
    d = np.linalg.norm(np.diff(cl_phys, axis=0), axis=1)
    s = np.zeros(len(cl_phys), float)
    s[1:] = np.cumsum(d)
    return s


def resample_polyline_by_step(cl_phys, step_mm=0.5):
    cl_phys = np.asarray(cl_phys, float)

    if cl_phys.shape[0] < 2:
        return cl_phys.copy()

    s = polyline_arclength(cl_phys)
    if s[-1] < 1e-9:
        return cl_phys[:1].copy()

    s_new = np.arange(0.0, s[-1] + 1e-9, step_mm)
    out = np.vstack([np.interp(s_new, s, cl_phys[:, i]) for i in range(3)]).T
    return out


def smooth_centerline_spline(cl_phys, smooth_s=2.0):
    cl_phys = np.asarray(cl_phys, float)

    if cl_phys.shape[0] < 4:
        return cl_phys.copy()

    try:
        k = min(3, len(cl_phys) - 1)
        tck, _ = splprep(cl_phys.T, s=smooth_s, k=k)
        u_new = np.linspace(0.0, 1.0, len(cl_phys))
        smooth = np.array(splev(u_new, tck)).T
        return smooth
    except Exception:
        return cl_phys.copy()


def reorder_centerline_prox_to_dist(cl_phys, lv_mask, origin, M):
    lv_vox = np.argwhere(lv_mask)
    if lv_vox.size == 0:
        return cl_phys

    lv_cent_phys = voxel_to_phys(lv_vox.astype(float), origin, M).mean(axis=0)

    d0 = np.linalg.norm(cl_phys[0] - lv_cent_phys)
    d1 = np.linalg.norm(cl_phys[-1] - lv_cent_phys)

    if d1 < d0:
        cl_phys = cl_phys[::-1].copy()

    return cl_phys


# ======================================================
# EXPORT
# ======================================================
def export_centerline_vtp(cl_phys, out_path):
    poly = pv.PolyData(cl_phys)
    poly.lines = np.hstack(([len(cl_phys)], np.arange(len(cl_phys))))
    poly.save(out_path)


def write_binary_nrrd(path, mask_bool, hdr):
    out_hdr = dict(hdr)
    vol = mask_bool.astype(np.uint8)
    nrrd.write(path, vol, out_hdr)


# ======================================================
# SETTINGS
# ======================================================
AORTA_SEGMENT_NAME = "Segment_1"
LV_SEGMENT_NAME    = "Segment_3"

FALLBACK_LABEL_AORTA = 1
FALLBACK_LABEL_LV    = 3

CENTERLINE_STEP_MM = 0.5
SPLINE_SMOOTHING   = 2.0


# ======================================================
# MAIN
# ======================================================
files = sorted([f for f in os.listdir(INPUT) if f.lower().endswith(".nrrd")])

for fname in files:
    patient = os.path.splitext(fname)[0]
    in_path = os.path.join(INPUT, fname)

    try:
        data, hdr = nrrd.read(in_path)
        origin, M = nrrd_affine_from_header(hdr)

        aorta = extract_mask(data, hdr, AORTA_SEGMENT_NAME, FALLBACK_LABEL_AORTA)
        lv    = extract_mask(data, hdr, LV_SEGMENT_NAME, FALLBACK_LABEL_LV)

        aorta = clean_mask(aorta)
        lv    = clean_mask(lv)

        # nuovo calcolo centerline direttamente nella maschera
        path_vox = compute_centerline_vox_from_mask(aorta, lv, origin, M)
        cl_phys = voxel_to_phys(path_vox, origin, M)

        cl_phys = resample_polyline_by_step(cl_phys, step_mm=CENTERLINE_STEP_MM)
        cl_phys = smooth_centerline_spline(cl_phys, smooth_s=SPLINE_SMOOTHING)
        cl_phys = reorder_centerline_prox_to_dist(cl_phys, lv, origin, M)

        export_centerline_vtp(
            cl_phys,
            os.path.join(OUT, f"{patient}_centerline_aorta.vtp")
        )

        write_binary_nrrd(
            os.path.join(OUT, f"{patient}_aorta_mask.nrrd"),
            aorta,
            hdr
        )

        L = polyline_arclength(cl_phys)[-1] if len(cl_phys) > 1 else 0.0
        print(f"[OK] {patient} | pts={len(cl_phys)} | length_mm={L:.1f}")

    except Exception as e:
        print(f"[SKIP] {patient}: {e}")