import os
import json
import glob
import itertools
import warnings
import numpy as np
import pandas as pd
import pyvista as pv
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch

from sklearn.decomposition import PCA
from scipy.stats import spearmanr, kruskal, mannwhitneyu
from sklearn.metrics import roc_curve, auc
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import LeaveOneOut
from statsmodels.stats.multitest import multipletests

warnings.filterwarnings("ignore")

matplotlib.rcParams.update({
    "font.family":       "DejaVu Sans",
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.titlesize":    11,
    "axes.labelsize":    10,
    "xtick.labelsize":   9,
    "ytick.labelsize":   9,
    "legend.fontsize":   8,
    "figure.dpi":        150,
})


# ======================================================
# SETTINGS  ← modifica solo questa sezione
# ======================================================
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import REGISTERED_DIR, CLINICAL_XLSX, PCA_DIR  # noqa: E402

AORTA_REG_DIR   = os.path.join(REGISTERED_DIR, "aorta")
RCA_REG_DIR     = os.path.join(REGISTERED_DIR, "rca")
OUT_DIR         = os.path.join(PCA_DIR, "joint")

ID_COL    = "ID"
GROUP_COL = "group"

# PCA
N_MODES_EXPORT   = 44      # modi ±2σ da esportare come mesh
MODE_STD_SCALE   = 2.0
CUMVAR_THRESHOLD = 90.0   # % varianza per selezionare PC per analisi clinica
MAX_PCS          = 50

# Figura scatter: quanti PC usare (PC1..PC_N)
N_PCS_SCATTER = 10

# Correlazioni
MIN_N_CORR    = 8
MIN_N_GROUP   = 3

# variabili cliniche numeriche
CLINICAL_NUMERIC_VARS = [
    "Age at diagnosis",
    "intramural_len",
    "takeoffAlpha",
    "Ellipticity_Ostium",
    "Ellipticity_2mmOstium",
    "Dmin_Ostium",
    "Dmin_2mmOstium",
    "Dmin_IM",
    "Area_Ostium",
    "Area_2mmOstium",
    "Minimal_Area",
    "BSA",
]

# criteri anatomici per ROC  {label: (colonna, operatore, soglia)}
ROC_VARS = {
    "Intramural length (≥10 mm)": ("intramural_len",     ">=", 10.0),
    "Ellipticity ostium (<0.6)":  ("Ellipticity_Ostium", "<",  0.6),
    "Take-off angle (<40°)":      ("takeoffAlpha",        "<",  40.0),
}
ROC_COLORS = ["#1f77b4", "#ff7f0e", "#9467bd"]

# palette gruppi
GRP_COLOR  = {"moderate": "#2E8B57", "high": "#800020"}
GRP_MARKER = {"moderate": "o",       "high": "^"}
GRP_LABEL  = {"moderate": "Moderate risk", "high": "High risk"}


# ======================================================
# OUTPUT FOLDERS
# ======================================================
SSM_DIR      = os.path.join(OUT_DIR, "ssm")
FIG_DIR      = os.path.join(OUT_DIR, "figures")
SCATTER_DIR  = os.path.join(FIG_DIR, "fig1_pc_scatters")
BOXPLOT_DIR  = os.path.join(FIG_DIR, "fig2_pc_boxplots")
CORR_DIR     = os.path.join(OUT_DIR, "correlations")

for d in [SSM_DIR, FIG_DIR, SCATTER_DIR, BOXPLOT_DIR, CORR_DIR]:
    os.makedirs(d, exist_ok=True)


# ======================================================
# UTILS
# ======================================================
def safe_num(s):
    if hasattr(s, "dtype") and s.dtype == object:
        s = s.astype(str).str.replace(",", ".", regex=False)
    return pd.to_numeric(s, errors="coerce")


def grp_legend():
    return [mpatches.Patch(color=GRP_COLOR[g], label=GRP_LABEL[g])
            for g in ["moderate", "high"]]


def load_mesh(path):
    return pv.read(path).triangulate().clean()


def normalize_mesh(mesh):
    pts    = np.asarray(mesh.points, dtype=float)
    center = pts.mean(axis=0)
    pts_c  = pts - center
    scale  = np.sqrt(np.mean(np.sum(pts_c ** 2, axis=1)))
    if not np.isfinite(scale) or scale <= 0:
        raise RuntimeError("Scala non valida")
    return (pts_c / scale), center, scale


def write_mesh(template, pts_flat, path):
    pts = np.asarray(pts_flat, dtype=float).reshape(-1, 3)
    m   = pv.PolyData(pts, template.faces.copy()).clean().triangulate()
    m.save(path)


def reconstruction_error(true_vec, recon_vec):
    return float(np.mean(np.linalg.norm(
        true_vec.reshape(-1, 3) - recon_vec.reshape(-1, 3), axis=1)))


# ======================================================
# STEP 1 — LOAD & BUILD SHAPE MATRIX
# ======================================================
print("=" * 60)
print("  STEP 1 — Loading registered meshes")
print("=" * 60)

aorta_paths = sorted(glob.glob(os.path.join(AORTA_REG_DIR, "*.vtk")))
rca_paths   = sorted(glob.glob(os.path.join(RCA_REG_DIR,   "*.vtk")))

aorta_map = {os.path.splitext(os.path.basename(p))[0]: p for p in aorta_paths}
rca_map   = {os.path.splitext(os.path.basename(p))[0]: p for p in rca_paths}

common_ids = sorted(set(aorta_map) & set(rca_map))
if len(common_ids) < 3:
    raise RuntimeError("Troppi pochi casi comuni aorta/rca")

# determine topology from first case
_a0 = load_mesh(aorta_map[common_ids[0]])
_r0 = load_mesh(rca_map[common_ids[0]])
N_AORTA_PTS = _a0.n_points
N_RCA_PTS   = _r0.n_points
template_aorta = _a0
template_rca   = _r0
print(f"  Template topology: aorta={N_AORTA_PTS} pts, rca={N_RCA_PTS} pts")

X          = []
kept_ids   = []
norm_info  = []

for sid in common_ids:
    try:
        a_mesh = load_mesh(aorta_map[sid])
        r_mesh = load_mesh(rca_map[sid])

        if a_mesh.n_points != N_AORTA_PTS:
            raise RuntimeError(f"Aorta n_pts mismatch: {a_mesh.n_points}")
        if r_mesh.n_points != N_RCA_PTS:
            raise RuntimeError(f"RCA n_pts mismatch: {r_mesh.n_points}")

        a_norm, a_c, a_s = normalize_mesh(a_mesh)
        r_norm, r_c, r_s = normalize_mesh(r_mesh)

        vec = np.concatenate([a_norm.ravel(), r_norm.ravel()])
        X.append(vec)
        kept_ids.append(sid)
        norm_info.append({
            ID_COL: sid,
            "aorta_cx": a_c[0], "aorta_cy": a_c[1], "aorta_cz": a_c[2], "aorta_scale": a_s,
            "rca_cx":   r_c[0], "rca_cy":   r_c[1], "rca_cz":   r_c[2], "rca_scale":   r_s,
        })

    except Exception as e:
        print(f"  [SKIP] {sid}: {e}")

if len(X) < 3:
    raise RuntimeError("Troppi pochi casi validi dopo il caricamento")

X = np.vstack(X)
print(f"  Shape matrix: {X.shape[0]} subjects × {X.shape[1]} features")

pd.DataFrame(norm_info).to_csv(
    os.path.join(SSM_DIR, "normalization_info.csv"), index=False)


# ======================================================
# STEP 2 — PCA
# ======================================================
print("\n" + "=" * 60)
print("  STEP 2 — PCA")
print("=" * 60)

pca    = PCA()
scores = pca.fit_transform(X)

n_modes  = scores.shape[1]
pc_cols  = [f"PC{i+1}" for i in range(n_modes)]
cum_pct  = np.cumsum(pca.explained_variance_ratio_) * 100

# select PCs for clinical analysis
sel_idx = np.where(cum_pct <= CUMVAR_THRESHOLD)[0].tolist()
if len(sel_idx) < n_modes:
    sel_idx.append(len(sel_idx))
sel_idx    = sel_idx[:MAX_PCS]
sel_pc_cols = [f"PC{i+1}" for i in sel_idx]

print(f"  Total modes: {n_modes}")
print(f"  PC1 variance: {pca.explained_variance_ratio_[0]*100:.1f}%")
print(f"  Modes for {CUMVAR_THRESHOLD}% cumvar: {len(sel_pc_cols)}")

# save scores
scores_df = pd.DataFrame(scores, columns=pc_cols)
scores_df.insert(0, ID_COL, kept_ids)
scores_df.to_csv(os.path.join(SSM_DIR, "pca_scores.csv"), index=False)
np.save(os.path.join(SSM_DIR, "scores.npy"),     scores)
np.save(os.path.join(SSM_DIR, "case_ids.npy"),   np.asarray(kept_ids, dtype=object))
np.save(os.path.join(SSM_DIR, "components.npy"), pca.components_)
np.save(os.path.join(SSM_DIR, "mean.npy"),       pca.mean_)
np.save(os.path.join(SSM_DIR, "X.npy"),          X)

# save variance
var_df = pd.DataFrame({
    "PC":                       pc_cols,
    "mode_index":               np.arange(1, n_modes + 1),
    "explained_variance":       pca.explained_variance_,
    "explained_variance_ratio": pca.explained_variance_ratio_,
    "explained_variance_pct":   pca.explained_variance_ratio_ * 100,
    "cumulative_ratio":         np.cumsum(pca.explained_variance_ratio_),
    "cumulative_pct":           cum_pct,
    "selected_for_clinical":    [i in sel_idx for i in range(n_modes)],
})
var_df.to_csv(os.path.join(SSM_DIR, "explained_variance.csv"), index=False)


# ======================================================
# STEP 3 — GENERALIZATION ERROR (LOO)
# ======================================================
print("\n" + "=" * 60)
print("  STEP 3 — Generalization error (LOO) …")
print("=" * 60)

n_subj     = X.shape[0]
max_modes  = min(n_subj - 1, n_modes)
loo_errors = np.full((n_subj, max_modes), np.nan)

for i in range(n_subj):
    X_train = np.delete(X, i, axis=0)
    x_test  = X[i]
    p_loo   = PCA()
    p_loo.fit(X_train)
    centered = x_test - p_loo.mean_
    for k in range(1, max_modes + 1):
        comps  = p_loo.components_[:k]
        recon  = p_loo.mean_ + (centered @ comps.T) @ comps
        loo_errors[i, k - 1] = reconstruction_error(x_test, recon)

gen_mean = np.nanmean(loo_errors, axis=0)
gen_std  = np.nanstd(loo_errors,  axis=0)

# normalize by mean shape size
global_scale = np.mean([r["aorta_scale"] for r in norm_info] +
                        [r["rca_scale"]   for r in norm_info])
gen_mean_norm = gen_mean / global_scale
gen_std_norm  = gen_std  / global_scale

gen_df = pd.DataFrame({
    "mode_index":                       np.arange(1, max_modes + 1),
    "generalization_error":             gen_mean,
    "generalization_error_std":         gen_std,
    "generalization_error_normalized":     gen_mean_norm,
    "generalization_error_normalized_std": gen_std_norm,
})
gen_df.to_csv(os.path.join(SSM_DIR, "generalization.csv"), index=False)
print(f"  LOO done. Min error at mode {np.argmin(gen_mean)+1}")


# ======================================================
# STEP 4 — MEAN SHAPE & MODE SHAPES
# ======================================================
print("\n" + "=" * 60)
print("  STEP 4 — Mean shape & mode shapes")
print("=" * 60)

mean_vec   = pca.mean_
split_idx  = N_AORTA_PTS * 3

write_mesh(template_aorta, mean_vec[:split_idx],
           os.path.join(SSM_DIR, "mean_aorta.stl"))
write_mesh(template_rca,   mean_vec[split_idx:],
           os.path.join(SSM_DIR, "mean_rca.stl"))

n_export = min(N_MODES_EXPORT, pca.components_.shape[0])
for k in range(n_export):
    sd   = np.sqrt(pca.explained_variance_[k])
    mode = pca.components_[k]
    for sign, tag in [(+1, "plus"), (-1, "minus")]:
        vec = mean_vec + sign * MODE_STD_SCALE * sd * mode
        write_mesh(template_aorta, vec[:split_idx],
                   os.path.join(SSM_DIR, f"mode{k+1:02d}_{tag}_aorta.stl"))
        write_mesh(template_rca,   vec[split_idx:],
                   os.path.join(SSM_DIR, f"mode{k+1:02d}_{tag}_rca.stl"))

print(f"  Mean shape + {n_export} modes (±{MODE_STD_SCALE}σ) saved.")


# ======================================================
# STEP 5 — CLINICAL DATA & MERGE
# ======================================================
print("\n" + "=" * 60)
print("  STEP 5 — Clinical data merge")
print("=" * 60)

clin_df = pd.read_excel(CLINICAL_XLSX)
clin_df[ID_COL]    = clin_df[ID_COL].astype(str).str.strip()
clin_df[GROUP_COL] = clin_df[GROUP_COL].astype(str).str.strip().str.lower()
clin_df[GROUP_COL] = clin_df[GROUP_COL].where(
    clin_df[GROUP_COL].isin(["moderate", "high"]), "unknown")

# keep only numeric vars that exist
num_vars = [v for v in CLINICAL_NUMERIC_VARS if v in clin_df.columns]

merged = pd.merge(scores_df, clin_df, on=ID_COL, how="inner")
merged[GROUP_COL] = merged[GROUP_COL].where(
    merged[GROUP_COL].isin(["moderate", "high"]), "unknown")

merged.to_csv(os.path.join(CORR_DIR, "merged_pca_clinical.csv"), index=False)
print(f"  Matched subjects: {len(merged)}")


# ======================================================
# STEP 6 — SPEARMAN CORRELATIONS
# ======================================================
print("\n" + "=" * 60)
print("  STEP 6 — Spearman correlations")
print("=" * 60)

rows = []
for pc in sel_pc_cols:
    for var in num_vars:
        x    = safe_num(merged[pc])
        y    = safe_num(merged[var])
        mask = x.notna() & y.notna()
        n    = int(mask.sum())
        if n < MIN_N_CORR:
            continue
        try:
            rho, p = spearmanr(x[mask], y[mask])
        except Exception:
            rho, p = np.nan, np.nan
        rows.append({"PC": pc, "Variable": var, "n": n,
                     "spearman_rho": rho, "spearman_p": p,
                     "abs_rho": abs(rho)})

corr_df = pd.DataFrame(rows)

if not corr_df.empty:
    corr_df["spearman_p_fdr"] = multipletests(
        corr_df["spearman_p"].fillna(1).values, method="fdr_bh")[1]
    corr_df = corr_df.sort_values(
        ["spearman_p_fdr", "abs_rho"], ascending=[True, False])

corr_df.to_csv(os.path.join(CORR_DIR, "spearman_results.csv"), index=False)

sig_corr  = corr_df[corr_df["spearman_p_fdr"] < 0.05].copy()
sugg_corr = corr_df[(corr_df["spearman_p"] < 0.05) &
                    (corr_df["abs_rho"] >= 0.30)].copy()

sig_corr.to_csv( os.path.join(CORR_DIR, "spearman_significant_fdr.csv"), index=False)
sugg_corr.to_csv(os.path.join(CORR_DIR, "spearman_suggestive.csv"),      index=False)
print(f"  Significant (FDR<0.05): {len(sig_corr)}  |  Suggestive: {len(sugg_corr)}")


# ======================================================
# STEP 7 — MANN-WHITNEY U ON PCs (paper Methods 2.5:
# "Differences in principal shape modes between high and moderate
#  risk patient groups were tested using the Mann–Whitney U test,
#  with p-values adjusted...using the Benjamini–Hochberg FDR
#  procedure (α = 0.05)")
# ======================================================
print("\n" + "=" * 60)
print("  STEP 7 — Mann-Whitney U on PCs")
print("=" * 60)

kw_rows = []
for pc in [c for c in merged.columns if c.startswith("PC")]:
    mod = safe_num(merged.loc[merged[GROUP_COL] == "moderate", pc]).dropna().values
    hi  = safe_num(merged.loc[merged[GROUP_COL] == "high",     pc]).dropna().values
    if len(mod) < MIN_N_GROUP or len(hi) < MIN_N_GROUP:
        continue
    try:
        U, p = mannwhitneyu(mod, hi, alternative="two-sided")
    except Exception:
        U, p = np.nan, np.nan
    # rank-biserial correlation: standard effect size for Mann-Whitney U
    # (analogous role to eta-squared for Kruskal-Wallis, but the correct
    # one for a 2-group rank-sum test)
    n1, n2 = len(mod), len(hi)
    rank_biserial = (1.0 - (2.0 * U) / (n1 * n2)) if (n1 * n2) > 0 else np.nan
    kw_rows.append({"pc": pc, "U": U, "p": p, "rank_biserial_r": rank_biserial,
                    "n_moderate": n1, "n_high": n2})

kw_df = pd.DataFrame(kw_rows)
if not kw_df.empty:
    kw_df["q"] = multipletests(kw_df["p"].fillna(1).values, method="fdr_bh")[1]
    kw_df       = kw_df.sort_values("p")

kw_df.to_csv(os.path.join(CORR_DIR, "mannwhitney_pc_results.csv"), index=False)

sig_pcs  = kw_df[kw_df["q"] < 0.05]["pc"].tolist() if not kw_df.empty else []
plot_pcs = sig_pcs if sig_pcs else \
           (kw_df.head(5)["pc"].tolist() if not kw_df.empty else
            [c for c in merged.columns if c.startswith("PC")][:5])

print(f"  Significant PCs (FDR q<0.05): {sig_pcs if sig_pcs else 'none — showing top 5 by p'}")


# ======================================================
# STEP 7b — LEAVE-ONE-OUT LOGISTIC REGRESSION ON SIGNIFICANT MODES
# ======================================================
print("\n" + "=" * 60)
print("  STEP 7b — LOO logistic regression on significant shape modes")
print("=" * 60)

ssm_roc_curves = {}   # label -> (fpr, tpr, auc)

def loo_logreg_auc(feature_cols, label):
    
    sub = merged[merged[GROUP_COL].isin(["moderate", "high"])].copy()
    for c in feature_cols:
        sub[c] = safe_num(sub[c])
    sub = sub.dropna(subset=feature_cols)
    if len(sub) < MIN_N_GROUP * 2:
        print(f"    [SKIP] {label}: too few complete cases ({len(sub)})")
        return None

    X_feat = sub[feature_cols].values
    y      = (sub[GROUP_COL] == "high").astype(int).values

    loo = LeaveOneOut()
    y_prob = np.full(len(y), np.nan)
    for train_idx, test_idx in loo.split(X_feat):
        if len(np.unique(y[train_idx])) < 2:
            continue  # cannot fit if the training fold has only one class
        clf = LogisticRegression(max_iter=1000)
        clf.fit(X_feat[train_idx], y[train_idx])
        y_prob[test_idx] = clf.predict_proba(X_feat[test_idx])[:, 1]

    valid = ~np.isnan(y_prob)
    if valid.sum() < MIN_N_GROUP * 2 or len(np.unique(y[valid])) < 2:
        print(f"    [SKIP] {label}: LOO predictions insufficient")
        return None

    fpr, tpr, _ = roc_curve(y[valid], y_prob[valid])
    roc_auc     = auc(fpr, tpr)
    print(f"    {label}: LOO AUC = {roc_auc:.3f}  (n={valid.sum()}, features={feature_cols})")
    return fpr, tpr, roc_auc

# univariate: mode 2 alone (if available and among tested PCs)
if "PC2" in merged.columns:
    res = loo_logreg_auc(["PC2"], "Mode 2 alone")
    if res is not None:
        ssm_roc_curves["Mode 2 alone (LOO logistic reg.)"] = res

# combined model: all Mann-Whitney-significant modes together
# (paper: modes 2, 15 and 19 were the ones found significant)
if len(sig_pcs) >= 2:
    res = loo_logreg_auc(sig_pcs, f"Combined significant modes ({', '.join(sig_pcs)})")
    if res is not None:
        ssm_roc_curves[f"Combined modes {'+'.join(sig_pcs)} (LOO logistic reg.)"] = res
elif len(sig_pcs) == 1 and sig_pcs != ["PC2"]:
    # fallback: still show the (only) significant mode found, if not PC2
    res = loo_logreg_auc(sig_pcs, f"Mode {sig_pcs[0]} alone")
    if res is not None:
        ssm_roc_curves[f"{sig_pcs[0]} alone (LOO logistic reg.)"] = res

pd.DataFrame([
    {"model": k, "auc": v[2]} for k, v in ssm_roc_curves.items()
]).to_csv(os.path.join(CORR_DIR, "ssm_mode_loo_logreg_auc.csv"), index=False)


# ======================================================
# SAVE SSM META
# ======================================================
meta = {
    "n_subjects":            int(len(kept_ids)),
    "n_aorta_points":        int(N_AORTA_PTS),
    "n_rca_points":          int(N_RCA_PTS),
    "n_features":            int(X.shape[1]),
    "n_modes":               int(n_modes),
    "selected_pc_cols":      sel_pc_cols,
    "cumvar_threshold":      float(CUMVAR_THRESHOLD),
    "n_modes_exported":      int(n_export),
    "mode_std_scale":        float(MODE_STD_SCALE),
    "clinical_xlsx":         CLINICAL_XLSX,
    "matched_subjects":      int(len(merged)),
    "significant_corr_fdr":  int(len(sig_corr)),
    "suggestive_corr":       int(len(sugg_corr)),
    "significant_pcs_mannwhitney_fdr": sig_pcs,
    "ssm_mode_loo_logreg_auc": {k: float(v[2]) for k, v in ssm_roc_curves.items()},
}
with open(os.path.join(SSM_DIR, "ssm_meta.json"), "w", encoding="utf-8") as f:
    json.dump(meta, f, indent=2)


# ======================================================
# FIGURES
# ======================================================
pc5  = [c for c in merged.columns if c.startswith("PC")][:N_PCS_SCATTER]
rng  = np.random.default_rng(42)

print("\n" + "=" * 60)
print("  STEP 8 — Paper figures")
print("=" * 60)

# ── FIG 1: scatter PCx vs PCy + marginal boxplots ────────────────────────
print("  [1] PC scatter plots …")
pairs = list(itertools.combinations(pc5, 2))

for pcx, pcy in pairs:
    fig_s = plt.figure(figsize=(6.5, 6.5))
    gs_s  = gridspec.GridSpec(2, 2, figure=fig_s,
                               width_ratios=[4, 1], height_ratios=[1, 4],
                               hspace=0.05, wspace=0.05)

    ax_sc     = fig_s.add_subplot(gs_s[1, 0])
    ax_bx     = fig_s.add_subplot(gs_s[1, 1], sharey=ax_sc)
    ax_tx     = fig_s.add_subplot(gs_s[0, 0], sharex=ax_sc)
    ax_corner = fig_s.add_subplot(gs_s[0, 1])
    ax_corner.axis("off")

    data_x = {g: safe_num(merged.loc[merged[GROUP_COL] == g, pcx]).dropna().values
               for g in ["moderate", "high"]}
    data_y = {g: safe_num(merged.loc[merged[GROUP_COL] == g, pcy]).dropna().values
               for g in ["moderate", "high"]}

    for grp in ["moderate", "high"]:
        sub = merged[merged[GROUP_COL] == grp]
        ax_sc.scatter(safe_num(sub[pcx]), safe_num(sub[pcy]),
                      s=55, alpha=0.85,
                      color=GRP_COLOR[grp], marker=GRP_MARKER[grp],
                      edgecolors="white", linewidths=0.4,
                      label=GRP_LABEL[grp], zorder=3)

    ax_sc.set_xlabel(pcx, fontsize=11)
    ax_sc.set_ylabel(pcy, fontsize=11)
    ax_sc.legend(handles=grp_legend(), fontsize=9, frameon=False)

    for ax_marg, data_dict, vert in [
            (ax_tx, data_x, False),
            (ax_bx, data_y, True)]:
        bp = ax_marg.boxplot(
            [data_dict["moderate"], data_dict["high"]],
            vert=vert, patch_artist=True,
            showfliers=False, widths=0.5,
            medianprops=dict(color="black", linewidth=1.8))
        for patch, grp in zip(bp["boxes"], ["moderate", "high"]):
            patch.set_facecolor(GRP_COLOR[grp])
            patch.set_alpha(0.65)
        ax_marg.tick_params(left=False, bottom=False,
                             labelbottom=False, labelleft=False)
        for sp in ax_marg.spines.values():
            sp.set_visible(False)

    fig_s.suptitle(f"PC Score Space — {pcx} vs {pcy}",
                   fontsize=12, fontweight="bold")
    fig_s.savefig(os.path.join(SCATTER_DIR, f"scatter_{pcx}_vs_{pcy}.png"),
                  dpi=300, bbox_inches="tight")
    plt.close(fig_s)

print(f"    → {len(pairs)} scatter plots in {SCATTER_DIR}")

# ── FIG 2: boxplot per PC significativo ──────────────────────────────────
print("  [2] PC boxplots …")

for pc in plot_pcs:
    data   = [safe_num(merged.loc[merged[GROUP_COL] == g, pc]).dropna().values
               for g in ["moderate", "high"]]
    labels = [GRP_LABEL[g] for g in ["moderate", "high"]]

    fig2, ax2 = plt.subplots(figsize=(5, 5.5))
    bp2 = ax2.boxplot(data, labels=labels, patch_artist=True,
                       showfliers=False, widths=0.45,
                       medianprops=dict(color="black", linewidth=2))
    for patch, grp in zip(bp2["boxes"], ["moderate", "high"]):
        patch.set_facecolor(GRP_COLOR[grp])
        patch.set_alpha(0.55)

    for i, (vals, grp) in enumerate(zip(data, ["moderate", "high"]), start=1):
        xj = rng.normal(loc=i, scale=0.06, size=len(vals))
        ax2.scatter(xj, vals, s=32, alpha=0.9,
                    color=GRP_COLOR[grp], marker=GRP_MARKER[grp],
                    edgecolors="white", linewidths=0.25, zorder=4)

    row   = kw_df[kw_df["pc"] == pc] if not kw_df.empty else pd.DataFrame()
    p_val = row["p"].values[0]    if len(row) else np.nan
    q_val = row["q"].values[0]    if len(row) else np.nan
    e_val = row["rank_biserial_r"].values[0] if len(row) else np.nan
    p_str = f"p={p_val:.3f}" if not np.isnan(p_val) else ""
    q_str = f"  q={q_val:.3f}" if not np.isnan(q_val) else ""
    e_str = f"  r={e_val:.2f}" if not np.isnan(e_val) else ""

    lbl = "Significant PC (Mann–Whitney U, FDR)" if pc in sig_pcs else "PC (top by p)"
    ax2.set_title(f"{lbl}: {pc}\n{p_str}{q_str}{e_str}",
                  fontweight="bold", pad=6)
    ax2.set_ylabel("PC score", fontsize=11)
    fig2.tight_layout()
    fig2.savefig(os.path.join(BOXPLOT_DIR, f"boxplot_{pc}.png"),
                 dpi=300, bbox_inches="tight")
    plt.close(fig2)

print(f"    → {len(plot_pcs)} boxplots in {BOXPLOT_DIR}")

# ── FIG 3: ROC — SSM shape modes (LOO logistic reg.) + anatomical classifiers ──
print("  [3] ROC curves …")
y_true = (merged[GROUP_COL] == "high").astype(int).values

fig3, ax3 = plt.subplots(figsize=(6.5, 6))
ax3.plot([0, 1], [0, 1], color="lightgray", linestyle="--", linewidth=1)

SSM_ROC_COLORS = ["#c0392b", "#1a5276"]
for (label, (fpr_s, tpr_s, auc_s)), color in zip(ssm_roc_curves.items(), SSM_ROC_COLORS):
    ax3.plot(fpr_s, tpr_s, color=color, linewidth=2.6,
             label=f"{label}  AUC={auc_s:.2f}")

for (label, (col, op, thr)), color in zip(ROC_VARS.items(), ROC_COLORS):
    if col not in merged.columns:
        continue
    vals  = safe_num(merged[col]).values
    valid = ~np.isnan(vals)
    if valid.sum() < 10:
        continue
    s = vals[valid] if op == ">=" else -vals[valid]
    fpr, tpr, _ = roc_curve(y_true[valid], s)
    roc_auc     = auc(fpr, tpr)
    if roc_auc < 0.5:
        fpr, tpr, _ = roc_curve(y_true[valid], -s)
        roc_auc     = auc(fpr, tpr)
    ax3.plot(fpr, tpr, color=color, linewidth=1.6, linestyle="--", alpha=0.85,
             label=f"{label} (reference)  AUC={roc_auc:.2f}")

ax3.set_xlabel("1 − Specificity  (False Positive Rate)")
ax3.set_ylabel("Sensitivity  (True Positive Rate)")
ax3.set_title("ROC — SSM Shape Modes (LOO logistic reg.)\nvs Anatomical Classifiers (High vs Moderate Risk)",
              fontweight="bold")
ax3.legend(loc="lower right", frameon=False, fontsize=7.5)
ax3.set_xlim(0, 1); ax3.set_ylim(0, 1.02)
fig3.tight_layout()
fig3.savefig(os.path.join(FIG_DIR, "fig3_roc_ssm_modes_and_anatomical.png"),
             dpi=300, bbox_inches="tight")
plt.close(fig3)

# ── FIG 4: pipeline flowchart ────────────────────────────────────────────
print("  [4] Pipeline flowchart …")

C_DATA = "#D6EAF8"; C_PROC = "#D5F5E3"
C_STAT = "#FCF3CF"; C_RISK = "#FADBD8"; C_EDGE = "#555555"

def fbox(ax, x, y, w, h, label, sub="", color="#EEE", fs=9):
    ax.add_patch(FancyBboxPatch((x-w/2, y-h/2), w, h,
                                boxstyle="round,pad=0.08",
                                facecolor=color, edgecolor=C_EDGE,
                                linewidth=1.2, zorder=3))
    ax.text(x, y+(0.12 if sub else 0), label,
            ha="center", va="center", fontsize=fs,
            fontweight="bold", zorder=4)
    if sub:
        ax.text(x, y-0.22, sub, ha="center", va="center",
                fontsize=7.5, color="#444", zorder=4, style="italic")

def farrow(ax, x1, y1, x2, y2):
    ax.annotate("", xy=(x2,y2), xytext=(x1,y1),
                arrowprops=dict(arrowstyle="-|>", color=C_EDGE,
                                lw=1.4, mutation_scale=14), zorder=2)

fig4, ax4 = plt.subplots(figsize=(14, 9))
ax4.set_xlim(0, 14); ax4.set_ylim(0, 9); ax4.axis("off")

fbox(ax4, 2.5, 8.0, 3.8, 0.85, "CT / MRI Imaging",   "DICOM acquisition",         C_DATA)
fbox(ax4, 7.0, 8.0, 3.8, 0.85, "Clinical Data",       "demographics, anatomy",     C_DATA)
fbox(ax4,11.5, 8.0, 3.8, 0.85, "Risk Criteria",       "len ≥10mm, elli, α<40°",    C_DATA)
fbox(ax4, 2.5, 6.6, 3.8, 0.85, "Segmentation",        "aorta + RCA meshes",        C_PROC)
farrow(ax4, 2.5,7.57, 2.5,7.02)
fbox(ax4, 2.5, 5.2, 3.8, 0.85, "Remeshing",           "uniform topology (pyacvd)", C_PROC)
farrow(ax4, 2.5,6.17, 2.5,5.62)
fbox(ax4, 2.5, 3.8, 3.8, 0.85, "CPD Registration",    "rigid + deformable (pycpd)",C_PROC)
farrow(ax4, 2.5,4.77, 2.5,4.22)
fbox(ax4, 2.5, 2.5, 3.8, 0.85, "Joint PCA",           "concat [aorta|rca] → PCA", C_PROC)
farrow(ax4, 2.5,3.37, 2.5,2.85)

for xb, lbl in [(1.0,"Compactness"),(2.5,"Generalization"),(4.0,"PC Scores")]:
    fbox(ax4, xb, 1.3, 1.6, 0.7, lbl, "", C_STAT, fs=8)
    farrow(ax4, 2.5,2.15, xb,1.65)

fbox(ax4,11.5, 6.6, 3.8, 0.85, "Risk Stratification",
     "2/3 criteria → high/moderate", C_RISK)
farrow(ax4,11.5,7.57,11.5,7.02)

fbox(ax4, 7.0, 5.2, 3.8, 0.85, "Clinical Association",
     "Spearman, Mann–Whitney U", C_STAT)
farrow(ax4, 7.0,7.57, 7.0,5.62)
farrow(ax4, 4.0,1.3,  7.0,5.2)
farrow(ax4,11.5,6.17, 9.0,5.55)

for xb, lbl in [(5.5,"ROC / AUC\n(LOO logistic reg.)"),(8.5,"MWU p-values\n+ rank-biserial r"),(11.5,"PC Boxplots")]:
    fbox(ax4, xb, 3.8, 2.6, 0.75, lbl, "", C_STAT, fs=8)
for xb in [5.5,8.5]:
    farrow(ax4, 7.0,4.77, xb,4.17)
farrow(ax4,11.5,6.17,11.5,4.17)

ax4.set_title("SSM Pipeline — AAORCA  (Anomalous Right Coronary Artery)",
              fontsize=13, fontweight="bold", pad=12)
ax4.legend(handles=[
    mpatches.Patch(facecolor=C_DATA, edgecolor=C_EDGE, label="Data / Input"),
    mpatches.Patch(facecolor=C_PROC, edgecolor=C_EDGE, label="Processing"),
    mpatches.Patch(facecolor=C_STAT, edgecolor=C_EDGE, label="Statistical Analysis"),
    mpatches.Patch(facecolor=C_RISK, edgecolor=C_EDGE, label="Risk Stratification"),
], loc="lower left", bbox_to_anchor=(0.01,0.01), frameon=True, fontsize=8)
fig4.tight_layout()
fig4.savefig(os.path.join(FIG_DIR, "fig4_pipeline_flowchart.png"),
             dpi=300, bbox_inches="tight")
plt.close(fig4)

# ── FIG 5: compactness ───────────────────────────────────────────────────
print("  [5] Compactness …")
fig5, ax5 = plt.subplots(figsize=(6.5, 4.5))
modes5 = np.arange(1, len(cum_pct)+1)
ax5.plot(modes5, cum_pct, color="#1a5276", linewidth=2.2,
         marker="o", markersize=4,
         markerfacecolor="white", markeredgewidth=1.5)
ax5.axhline(90, color="#c0392b", linestyle="--", linewidth=1.2, label="90% threshold")
ax5.axhline(95, color="#e67e22", linestyle=":",  linewidth=1.2, label="95% threshold")
idx90 = np.searchsorted(cum_pct, 90)
if idx90 < len(modes5):
    ax5.axvline(modes5[idx90], color="#c0392b", linestyle="--",
                linewidth=0.8, alpha=0.5)
    ax5.annotate(f"PC{modes5[idx90]}",
                 xy=(modes5[idx90], cum_pct[idx90]),
                 xytext=(modes5[idx90]+0.5, cum_pct[idx90]-5),
                 fontsize=8, color="#c0392b",
                 arrowprops=dict(arrowstyle="-", color="#c0392b", lw=0.8))
ax5.set_xlabel("Number of modes")
ax5.set_ylabel("Cumulative explained variance (%)")
ax5.set_title("Compactness — Cumulative Explained Variance", fontweight="bold")
ax5.legend(frameon=False)
ax5.set_xlim(1, min(len(modes5), 30)); ax5.set_ylim(0, 101)
fig5.tight_layout()
fig5.savefig(os.path.join(FIG_DIR, "fig5_compactness.png"),
             dpi=300, bbox_inches="tight")
plt.close(fig5)

# ── FIG 6: generalization ────────────────────────────────────────────────
print("  [6] Generalization error …")
fig6, ax6 = plt.subplots(figsize=(6.5, 4.5))
g_modes = gen_df["mode_index"].values
g_mean  = gen_df["generalization_error_normalized"].values
g_std   = gen_df["generalization_error_normalized_std"].values
ax6.plot(g_modes, g_mean, color="#1a5276", linewidth=2.2,
         marker="o", markersize=4,
         markerfacecolor="white", markeredgewidth=1.5, label="Mean LOO error")
ax6.fill_between(g_modes, g_mean-g_std, g_mean+g_std,
                 color="#1a5276", alpha=0.18, label="±1 SD")
if len(g_mean) > 4:
    elbow = np.argmin(np.diff(g_mean, n=2)) + 2
    ax6.axvline(g_modes[elbow], color="#c0392b", linestyle="--",
                linewidth=1.2, alpha=0.7, label=f"Elbow ≈ PC{g_modes[elbow]}")
ax6.set_xlabel("Number of modes")
ax6.set_ylabel("Normalized reconstruction error")
ax6.set_title("Generalization Error — Leave-One-Out", fontweight="bold")
ax6.legend(frameon=False)
ax6.set_xlim(1, min(len(g_modes), 30))
fig6.tight_layout()
fig6.savefig(os.path.join(FIG_DIR, "fig6_generalization.png"),
             dpi=300, bbox_inches="tight")
plt.close(fig6)

# ── FIG 7: Kruskal-Wallis clinical parameters ─────────────────────────────
print("  [7] Kruskal-Wallis parameters …")
kw7_rows = []
for var in num_vars:
    mod = safe_num(merged.loc[merged[GROUP_COL] == "moderate", var]).dropna().values
    hi  = safe_num(merged.loc[merged[GROUP_COL] == "high",     var]).dropna().values
    if len(mod) < MIN_N_GROUP or len(hi) < MIN_N_GROUP:
        continue
    try:
        H, p = kruskal(mod, hi)
    except Exception:
        H, p = np.nan, np.nan
    n_tot = len(mod) + len(hi)
    eta2  = (H - 1) / (n_tot - 1) if n_tot > 2 else np.nan
    kw7_rows.append({"var": var, "H": H, "p": p, "eta2": eta2,
                     "med_mod": np.nanmedian(mod), "med_hi": np.nanmedian(hi)})

kw7_df = pd.DataFrame(kw7_rows)
if not kw7_df.empty:
    kw7_df["q"] = multipletests(kw7_df["p"].fillna(1).values, method="fdr_bh")[1]
    kw7_df = kw7_df.sort_values("p").reset_index(drop=True)
kw7_df.to_csv(os.path.join(CORR_DIR, "kruskal_clinical_results.csv"), index=False)

n7     = len(kw7_df)
fig7, ax7 = plt.subplots(figsize=(10, max(5, 0.55*n7+2)))
y7     = np.arange(n7)
ax7.barh(y7+0.18, kw7_df["med_mod"], height=0.34,
         color=GRP_COLOR["moderate"], alpha=0.80, label="Moderate (median)")
ax7.barh(y7-0.18, kw7_df["med_hi"],  height=0.34,
         color=GRP_COLOR["high"],     alpha=0.80, label="High (median)")
for i, row in kw7_df.iterrows():
    sig  = "***" if row.p < 0.001 else "**" if row.p < 0.01 \
           else "*" if row.p < 0.05 else "ns"
    col  = "#c0392b" if row.p < 0.05 else "#888"
    eta_s = f"  η²={row.eta2:.2f}" if not np.isnan(row.eta2) else ""
    ax7.text(max(row.med_mod, row.med_hi)*1.03, i,
             f"{sig}  p={row.p:.3f}  q={row.q:.3f}{eta_s}",
             va="center", fontsize=7.5, color=col)
ax7.set_yticks(y7)
ax7.set_yticklabels(kw7_df["var"], fontsize=9)
ax7.set_xlabel("Median value")
ax7.set_title("Clinical Parameters — Kruskal-Wallis\n(High vs Moderate Risk)",
              fontweight="bold")
ax7.legend(frameon=False); ax7.invert_yaxis()
fig7.tight_layout()
fig7.savefig(os.path.join(FIG_DIR, "fig7_kruskal_parameters.png"),
             dpi=300, bbox_inches="tight")
plt.close(fig7)

# ── FIG 8: feature importance ────────────────────────────────────────────
print("  [8] Feature importance …")
feat_data = []
y_fi = (merged[GROUP_COL] == "high").astype(int).values

for label, (col, op, thr) in ROC_VARS.items():
    if col not in merged.columns:
        continue
    vals  = safe_num(merged[col]).values
    valid = ~np.isnan(vals)

    def pct_meets(v):
        return ((v >= thr) if op == ">=" else (v < thr)).mean() * 100

    s = vals[valid] if op == ">=" else -vals[valid]
    fpr_f, tpr_f, _ = roc_curve(y_fi[valid], s)
    roc_f = auc(fpr_f, tpr_f)
    if roc_f < 0.5:
        fpr_f, tpr_f, _ = roc_curve(y_fi[valid], -s)
        roc_f = auc(fpr_f, tpr_f)

    feat_data.append({
        "label":     label,
        "pct_total": pct_meets(vals[valid]),
        "pct_high":  pct_meets(safe_num(merged.loc[merged[GROUP_COL]=="high",   col]).dropna().values),
        "pct_mod":   pct_meets(safe_num(merged.loc[merged[GROUP_COL]=="moderate",col]).dropna().values),
        "auc":       roc_f,
    })

feat_df = pd.DataFrame(feat_data)

fig8, axes8 = plt.subplots(1, 2, figsize=(13, 4.5),
                            gridspec_kw={"width_ratios": [2, 1]})
ax8l, ax8r = axes8
n8 = len(feat_df); x8 = np.arange(n8); w8 = 0.26

ax8l.bar(x8-w8, feat_df["pct_total"], width=w8, color="#4477AA", alpha=0.85,
          label="Total population")
ax8l.bar(x8,    feat_df["pct_high"],  width=w8, color=GRP_COLOR["high"],     alpha=0.85,
          label=GRP_LABEL["high"])
ax8l.bar(x8+w8, feat_df["pct_mod"],   width=w8, color=GRP_COLOR["moderate"], alpha=0.85,
          label=GRP_LABEL["moderate"])
for xi, row in zip(x8, feat_df.itertuples()):
    for xoff, val in zip([-w8, 0, w8],
                          [row.pct_total, row.pct_high, row.pct_mod]):
        ax8l.text(xi+xoff, val+1.5, f"{val:.0f}%",
                  ha="center", va="bottom", fontsize=7.5, fontweight="bold")
ax8l.set_xticks(x8)
ax8l.set_xticklabels(feat_df["label"], fontsize=9)
ax8l.set_ylabel("% of population meeting criterion")
ax8l.set_ylim(0, 115)
ax8l.set_title("Criterion Prevalence by Risk Group", fontweight="bold")
ax8l.legend(frameon=False)

bars8 = ax8r.barh(feat_df["label"][::-1], feat_df["auc"][::-1],
                   color=ROC_COLORS[:len(feat_df)][::-1], alpha=0.85, height=0.45)
ax8r.axvline(0.5, color="gray", linestyle="--", linewidth=1)
for bar, val in zip(bars8, feat_df["auc"][::-1]):
    ax8r.text(val+0.01, bar.get_y()+bar.get_height()/2,
              f"AUC={val:.2f}", va="center", fontsize=8.5, fontweight="bold")
ax8r.set_xlim(0, 1.12)
ax8r.set_xlabel("AUC (ROC)")
ax8r.set_title("Discriminative Power\n(High vs Moderate)", fontweight="bold")

fig8.suptitle("Anatomical Feature Importance — Risk Stratification",
              fontsize=13, fontweight="bold")
fig8.tight_layout()
fig8.savefig(os.path.join(FIG_DIR, "fig8_feature_importance.png"),
             dpi=300, bbox_inches="tight")
plt.close(fig8)

# ── Scatter suggestive correlations (coloured by group) ──────────────────
print("  [+] Suggestive correlation scatter plots …")
sugg_scatter_dir = os.path.join(FIG_DIR, "fig9_suggestive_scatter")
os.makedirs(sugg_scatter_dir, exist_ok=True)

for _, row in sugg_corr.iterrows():
    pc  = row["PC"]
    var = row["Variable"]
    x   = safe_num(merged[pc])
    y   = safe_num(merged[var])
    msk = x.notna() & y.notna()
    xv  = x[msk].values; yv = y[msk].values
    if len(xv) < 3:
        continue

    fig_c, ax_c = plt.subplots(figsize=(6, 5.5))
    for grp in ["moderate", "high"]:
        gm = merged.loc[msk, GROUP_COL] == grp
        ax_c.scatter(xv[gm.values], yv[gm.values],
                     s=55, alpha=0.85,
                     color=GRP_COLOR[grp], marker=GRP_MARKER[grp],
                     edgecolors="white", linewidths=0.4,
                     label=GRP_LABEL[grp], zorder=3)
    ax_c.set_xlabel(pc); ax_c.set_ylabel(var)
    ax_c.set_title(f"{pc} vs {var}\n"
                   f"ρ={row['spearman_rho']:.3f}  "
                   f"p={row['spearman_p']:.4g}  "
                   f"q={row['spearman_p_fdr']:.4g}",
                   fontsize=10)
    ax_c.legend(handles=grp_legend(), fontsize=8, frameon=False)
    fname = f"{pc}_vs_{var}".replace(" ", "_").replace("/", "-")
    fig_c.tight_layout()
    fig_c.savefig(os.path.join(sugg_scatter_dir, f"{fname}.png"),
                  dpi=300, bbox_inches="tight")
    plt.close(fig_c)

# ======================================================
# FINAL SUMMARY
# ======================================================
print("\n" + "=" * 60)
print("  DONE")
print("=" * 60)
print(f"  Subjects:          {len(kept_ids)}")
print(f"  Matched clinical:  {len(merged)}")
print(f"  PC1 variance:      {pca.explained_variance_ratio_[0]*100:.1f}%")
print(f"  90% cumvar at:     PC{idx90+1}")
print(f"  Sig. corr (FDR):   {len(sig_corr)}")
print(f"  Suggestive corr:   {len(sugg_corr)}")
print(f"  Sig. PCs (Mann-Whitney U, FDR): {sig_pcs if sig_pcs else 'none'}")
for k, v in ssm_roc_curves.items():
    print(f"  {k}: AUC={v[2]:.3f}")
print(f"\n  Outputs:")
print(f"    SSM:     {SSM_DIR}")
print(f"    Figures: {FIG_DIR}")
print(f"    Corr:    {CORR_DIR}")
print("=" * 60)