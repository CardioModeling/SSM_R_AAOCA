import os
import numpy as np
import nrrd
import pyvista as pv
import networkx as nx

from scipy.ndimage import (
    binary_fill_holes,
    label as cc_label,
    distance_transform_edt,
    convolve,
)
from scipy.interpolate import splprep, splev
from scipy.spatial import cKDTree
from skimage.morphology import ball, closing, skeletonize


# ======================================================
# SETTINGS
# ======================================================
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RAW_NRRD_DIR, AORTA_PREPROCESSED_DIR, RCA_PREPROCESSED_DIR  # noqa: E402

INPUT = RAW_NRRD_DIR
AORTA_IN = AORTA_PREPROCESSED_DIR
OUT = RCA_PREPROCESSED_DIR

os.makedirs(OUT, exist_ok=True)

COR_SEGMENT_NAME = "Segment_2"
FALLBACK_LABEL_COR = 2

MIN_COMP_VOXELS = 80
CENTERLINE_STEP_MM = 0.5
SPLINE_SMOOTHING = 1.0
RCA_CUT_LEN_MM = 70.0


# ======================================================
# NRRD GEOMETRY
# ======================================================
def nrrd_affine_from_header(hdr):
    origin = np.array(hdr.get("space origin", [0, 0, 0]), float)
    sd = hdr.get("space directions", None)

    if sd is None:
        sp = np.array(hdr.get("spacings", [1, 1, 1]), float)[:3]
        M = np.diag(sp)
        return origin, M

    cols = []
    for v in sd[:3]:
        if v is None:
            cols.append(np.array([0.0, 0.0, 0.0], float))
        else:
            cols.append(np.array(v, float))

    M = np.column_stack(cols)
    return origin, M


def voxel_to_phys(ijk, origin, M):
    ijk = np.asarray(ijk, float)
    return origin[None, :] + ijk @ M.T


def spacing_from_M(M):
    return np.linalg.norm(M, axis=0)


def step_length_phys(delta, M):
    return float(np.linalg.norm(M @ delta.astype(float)))


# ======================================================
# SEGMENT EXTRACTION
# ======================================================
def find_segment_indices_in_header(hdr):
    idxs = set()
    for k in hdr.keys():
        if k.startswith("Segment") and "_" in k:
            s = k.split("_")[0].replace("Segment", "")
            if s.isdigit():
                idxs.add(int(s))
    return sorted(idxs)


def find_label_value_for_segment_name(hdr, segment_name, fallback=None):
    for i in find_segment_indices_in_header(hdr):
        name = hdr.get(f"Segment{i}_Name", "")
        if name == segment_name:
            return int(hdr.get(f"Segment{i}_LabelValue", i))
    return fallback


def extract_mask(data, hdr, segment_name, fallback_label):
    label_value = find_label_value_for_segment_name(
        hdr, segment_name, fallback=fallback_label
    )
    return (data == label_value)


# ======================================================
# CLEANING
# ======================================================
def clean_mask(mask):
    mask = binary_fill_holes(mask)
    mask = closing(mask, ball(1))
    return mask.astype(bool)


def split_connected_components(mask_bool, min_voxels=80):
    lab, n = cc_label(mask_bool)
    comps = []
    for k in range(1, n + 1):
        comp = (lab == k)
        if np.count_nonzero(comp) >= min_voxels:
            comps.append(comp)

    comps.sort(key=lambda c: np.count_nonzero(c), reverse=True)
    return comps


# ======================================================
# AORTA CENTERLINE HELPERS
# ======================================================
def load_aorta_centerline_vtp(vtp_path):
    poly = pv.read(vtp_path)
    pts = np.asarray(poly.points, float)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] < 2:
        raise RuntimeError(f"Centerline aorta non valida: {vtp_path}")
    return pts


def closest_point_on_polyline(P, pts):
    tree = cKDTree(pts)
    _, idx = tree.query(P, k=1)
    idx = int(idx)
    return idx, pts[idx]


def unit(v):
    v = np.asarray(v, float)
    n = np.linalg.norm(v)
    return v / (n + 1e-12)


def tangent_at_index(pts, idx):
    N = len(pts)
    if N < 2:
        return np.array([0, 0, 1], float)

    if idx <= 0:
        t = pts[1] - pts[0]
    elif idx >= N - 1:
        t = pts[N - 1] - pts[N - 2]
    else:
        t = pts[idx + 1] - pts[idx - 1]

    return unit(t)


def side_value_from_ostium(ostium_phys, aorta_cl_pts, M):
    up_ref = unit(np.array(M[:, 2], float))

    idx, proj = closest_point_on_polyline(ostium_phys, aorta_cl_pts)
    T = tangent_at_index(aorta_cl_pts, idx)

    side_axis = np.cross(up_ref, T)
    if np.linalg.norm(side_axis) < 1e-8:
        up_ref2 = unit(np.array(M[:, 0], float))
        side_axis = np.cross(up_ref2, T)

    side_axis = unit(side_axis)

    R = ostium_phys - proj
    if np.linalg.norm(R) < 1e-8:
        return 0.0

    R = unit(R)
    return float(np.dot(R, side_axis))


# ======================================================
# OSTIUM DETECTION
# ======================================================
def choose_ostium_voxel(comp_mask, origin, M, aorta_cl_pts):
    vox = np.argwhere(comp_mask)
    if vox.size == 0:
        raise RuntimeError("Componente vuota")

    xyz = voxel_to_phys(vox.astype(float), origin, M)
    tree = cKDTree(aorta_cl_pts)
    d, _ = tree.query(xyz, k=1)

    idx = int(np.argmin(d))
    ostium_vox = tuple(vox[idx])
    ostium_phys = xyz[idx]

    return ostium_vox, ostium_phys


# ======================================================
# GRAPH ON FULL MASK
# ======================================================
def build_mask_graph_with_center_preference(mask_bool, M):
    vox = np.argwhere(mask_bool)
    if vox.size == 0:
        raise RuntimeError("Maschera vuota")

    spacing = spacing_from_M(M)
    dist = distance_transform_edt(mask_bool, sampling=spacing)

    G = nx.Graph()

    dirs = [(i, j, k) for i in (-1, 0, 1)
                      for j in (-1, 0, 1)
                      for k in (-1, 0, 1)
                      if not (i == j == k == 0)]

    for v in vox:
        G.add_node(tuple(v))

    nodes = set(G.nodes)

    for x, y, z in nodes:
        d_here = float(dist[x, y, z])

        for dx, dy, dz in dirs:
            n = (x + dx, y + dy, z + dz)
            if n not in nodes:
                continue

            d_next = float(dist[n[0], n[1], n[2]])
            step_mm = step_length_phys(np.array([dx, dy, dz]), M)

            center_bonus = max(0.5 * (d_here + d_next), 1e-3)
            w = step_mm / center_bonus

            G.add_edge((x, y, z), n, weight=w)

    return G


# ======================================================
# SKELETON GRAPH FOR BRANCH PRUNING
# ======================================================
def skeleton_endpoints(skel):
    kernel = np.ones((3, 3, 3), int)
    kernel[1, 1, 1] = 0
    neigh = convolve(skel.astype(int), kernel)
    eps = [tuple(p) for p in np.argwhere((skel == 1) & (neigh == 1))]
    return eps


def build_skeleton_graph(skel, M):
    vox = np.argwhere(skel)
    if vox.size == 0:
        return [], None

    G = nx.Graph()
    for v in vox:
        G.add_node(tuple(v))

    dirs = [(i, j, k) for i in (-1, 0, 1)
                     for j in (-1, 0, 1)
                     for k in (-1, 0, 1)
                     if not (i == j == k == 0)]

    nodes = set(G.nodes)
    for x, y, z in nodes:
        for dx, dy, dz in dirs:
            n = (x + dx, y + dy, z + dz)
            if n in nodes:
                w = step_length_phys(np.array([dx, dy, dz]), M)
                G.add_edge((x, y, z), n, weight=w)

    return list(nodes), G


def find_ostium_on_component_skeleton(comp_mask, origin, M, aorta_cl_pts):
    """
    Ostio = endpoint dello skeleton più vicino alla centerline aortica.
    """
    skel = skeletonize(comp_mask, method="lee")
    nodes, G = build_skeleton_graph(skel, M)
    if not nodes or G is None or len(G.nodes) < 2:
        return None

    eps = skeleton_endpoints(skel)
    if len(eps) == 0:
        eps = nodes

    aorta_tree = cKDTree(aorta_cl_pts)

    best_ep = None
    best_d = np.inf
    for ep in eps:
        ep_phys = voxel_to_phys(np.array([ep], float), origin, M)[0]
        d, _ = aorta_tree.query(ep_phys, k=1)
        if d < best_d:
            best_d = d
            best_ep = ep

    if best_ep is None:
        return None

    ostium_phys = voxel_to_phys(np.array([best_ep], float), origin, M)[0]
    return skel, nodes, G, tuple(best_ep), ostium_phys


def extract_main_trunk_mask(comp_mask, origin, M, skel, G, ostium_node, cut_len_mm):
    
    dist_map = nx.single_source_dijkstra_path_length(G, ostium_node, weight="weight")
    if len(dist_map) == 0:
        return None

    endpoints = [n for n in G.nodes if G.degree[n] == 1]
    if len(endpoints) > 0:
        far_node = max(endpoints, key=lambda n: dist_map.get(n, -1.0))
    else:
        far_node = max(dist_map.keys(), key=lambda n: dist_map[n])

    try:
        trunk_path = nx.shortest_path(G, ostium_node, far_node, weight="weight")
    except Exception:
        return None

    trunk_set = set(trunk_path)

    skel_nodes = np.array(list(dist_map.keys()), int)
    skel_dist = np.array([dist_map[tuple(v)] for v in skel_nodes], float)
    skel_phys = voxel_to_phys(skel_nodes.astype(float), origin, M)

    vox = np.argwhere(comp_mask)
    if vox.size == 0:
        return None
    vox_phys = voxel_to_phys(vox.astype(float), origin, M)

    tree = cKDTree(skel_phys)
    _, idx = tree.query(vox_phys, k=1)

    nearest_nodes = [tuple(skel_nodes[i]) for i in idx]
    nearest_dist = skel_dist[idx]

    keep = np.zeros(len(vox), dtype=bool)
    for i, n in enumerate(nearest_nodes):
        if n in trunk_set and nearest_dist[i] <= cut_len_mm:
            keep[i] = True

    out = np.zeros(comp_mask.shape, dtype=bool)
    out[vox[keep, 0], vox[keep, 1], vox[keep, 2]] = True
    return out


# ======================================================
# DISTAL POINT + ROBUST CENTERLINE
# ======================================================
def choose_distal_voxel(comp_mask, origin, M, ostium_vox):
    G = build_mask_graph_with_center_preference(comp_mask, M)

    lengths = nx.single_source_dijkstra_path_length(G, ostium_vox, weight="weight")
    if len(lengths) == 0:
        raise RuntimeError("Dijkstra fallita nella componente RCA")

    distal_vox = max(lengths.keys(), key=lambda k: lengths[k])
    return distal_vox


def compute_centerline_vox_from_component(comp_mask, origin, M, aorta_cl_pts):
    ostium_vox, ostium_phys = choose_ostium_voxel(comp_mask, origin, M, aorta_cl_pts)
    distal_vox = choose_distal_voxel(comp_mask, origin, M, ostium_vox)

    G = build_mask_graph_with_center_preference(comp_mask, M)

    try:
        path = nx.shortest_path(G, ostium_vox, distal_vox, weight="weight")
    except Exception as e:
        raise RuntimeError(f"Path RCA non trovato: {e}")

    return np.array(path, dtype=float), ostium_vox, ostium_phys


# ======================================================
# CENTERLINE POST-PROCESSING
# ======================================================
def polyline_arclength(cl_phys):
    d = np.linalg.norm(np.diff(cl_phys, axis=0), axis=1)
    s = np.zeros(len(cl_phys), float)
    s[1:] = np.cumsum(d)
    return s


def resample_polyline_by_step(cl_phys, step_mm=0.5):
    cl_phys = np.asarray(cl_phys, float)

    if cl_phys.shape[0] < 2:
        return cl_phys.copy()

    s = polyline_arclength(cl_phys)
    if s[-1] < 1e-9:
        return cl_phys[:1].copy()

    s_new = np.arange(0.0, s[-1] + 1e-9, step_mm)
    out = np.vstack([np.interp(s_new, s, cl_phys[:, i]) for i in range(3)]).T
    return out


def smooth_centerline_spline(cl_phys, smooth_s=1.0):
    cl_phys = np.asarray(cl_phys, float)

    if cl_phys.shape[0] < 4:
        return cl_phys.copy()

    try:
        k = min(3, len(cl_phys) - 1)
        tck, _ = splprep(cl_phys.T, s=smooth_s, k=k)
        u_new = np.linspace(0.0, 1.0, len(cl_phys))
        smooth = np.array(splev(u_new, tck)).T
        return smooth
    except Exception:
        return cl_phys.copy()


def clip_centerline_by_length(cl_phys, max_len_mm=70.0):
    cl_phys = np.asarray(cl_phys, float)

    if cl_phys.shape[0] < 2:
        return cl_phys.copy()

    s = polyline_arclength(cl_phys)
    if s[-1] <= max_len_mm:
        return cl_phys.copy()

    idx = int(np.searchsorted(s, max_len_mm, side="left"))
    idx = max(1, min(idx, len(cl_phys) - 1))
    return cl_phys[: idx + 1].copy()


# ======================================================
# EXPORT
# ======================================================
def export_centerline_vtp(cl_phys, out_path):
    poly = pv.PolyData(cl_phys)
    poly.lines = np.hstack(([len(cl_phys)], np.arange(len(cl_phys))))
    poly.save(out_path)


def write_binary_nrrd(path, mask_bool, hdr):
    out_hdr = dict(hdr)
    vol = mask_bool.astype(np.uint8)
    nrrd.write(path, vol, out_hdr)


# ======================================================
# MAIN
# ======================================================
files = sorted([f for f in os.listdir(INPUT) if f.lower().endswith(".nrrd")])

for fname in files:
    patient = os.path.splitext(fname)[0]
    in_path = os.path.join(INPUT, fname)

    try:
        aorta_cl_path = os.path.join(AORTA_IN, f"{patient}_centerline_aorta.vtp")
        if not os.path.exists(aorta_cl_path):
            raise RuntimeError(f"Centerline aorta mancante: {aorta_cl_path}")

        aorta_cl_pts = load_aorta_centerline_vtp(aorta_cl_path)

        data, hdr = nrrd.read(in_path)
        origin, M = nrrd_affine_from_header(hdr)

        cor_mask = extract_mask(data, hdr, COR_SEGMENT_NAME, FALLBACK_LABEL_COR)
        cor_mask = clean_mask(cor_mask)

        comps = split_connected_components(cor_mask, min_voxels=MIN_COMP_VOXELS)
        if len(comps) == 0:
            raise RuntimeError("Nessuna componente coronarica valida")

        comps = comps[:2]

        candidates = []

        for comp in comps:
            try:
                # ostio per scelta RCA destra/sinistra
                ost_vox, ost_phys = choose_ostium_voxel(comp, origin, M, aorta_cl_pts)
                sv = side_value_from_ostium(ost_phys, aorta_cl_pts, M)

                # pruning ramificazioni secondarie
                skel_res = find_ostium_on_component_skeleton(comp, origin, M, aorta_cl_pts)
                if skel_res is None:
                    continue

                skel, nodes, G_skel, ost_node_skel, ost_phys_skel = skel_res
                comp_pruned = extract_main_trunk_mask(
                    comp, origin, M, skel, G_skel, ost_node_skel, RCA_CUT_LEN_MM
                )
                if comp_pruned is None or np.count_nonzero(comp_pruned) == 0:
                    continue

                candidates.append((sv, comp_pruned, ost_vox, ost_phys))

            except Exception:
                continue

        if len(candidates) == 0:
            raise RuntimeError("Impossibile determinare la RCA")

        # RCA = side_value massimo
        candidates.sort(key=lambda x: x[0])
        sv_rca, rca_comp, ost_vox_rca, ost_phys_rca = candidates[-1]

        # centerline robusta sulla trunk già pulita dalle ramificazioni
        path_vox, ost_vox_rca, ost_phys_rca = compute_centerline_vox_from_component(
            rca_comp, origin, M, aorta_cl_pts
        )

        cl_phys = voxel_to_phys(path_vox, origin, M)
        cl_phys = resample_polyline_by_step(cl_phys, step_mm=CENTERLINE_STEP_MM)
        cl_phys = smooth_centerline_spline(cl_phys, smooth_s=SPLINE_SMOOTHING)
        cl_phys = clip_centerline_by_length(cl_phys, max_len_mm=RCA_CUT_LEN_MM)

        export_centerline_vtp(
            cl_phys,
            os.path.join(OUT, f"{patient}_centerline_rca.vtp")
        )

        write_binary_nrrd(
            os.path.join(OUT, f"{patient}_rca_mask.nrrd"),
            rca_comp,
            hdr
        )

        np.save(
            os.path.join(OUT, f"{patient}_ostium.npy"),
            np.asarray(ost_phys_rca, float)
        )

        L = polyline_arclength(cl_phys)[-1] if len(cl_phys) > 1 else 0.0
        print(
            f"[OK] {patient} | RCA pts={len(cl_phys)} | "
            f"length_mm={L:.1f} | side_value={sv_rca:.3f}"
        )

    except Exception as e:
        print(f"[SKIP] {patient}: {e}")