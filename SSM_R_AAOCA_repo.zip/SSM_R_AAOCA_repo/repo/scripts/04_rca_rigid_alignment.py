import os
import re
import glob
import numpy as np
import nrrd
import pyvista as pv
import matplotlib.pyplot as plt

from scipy.ndimage import map_coordinates


# ======================================================
# SETTINGS
# ======================================================
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import RCA_PREPROCESSED_DIR, RCA_ALIGNED_RIGID_DIR  # noqa: E402

INPUT_DIR = RCA_PREPROCESSED_DIR
OUT_DIR   = RCA_ALIGNED_RIGID_DIR

CL_PATTERN   = "*_centerline_rca.vtp"
MASK_PATTERN = "*_rca_mask.nrrd"
OST_PATTERN  = "*_ostium.npy"

N_SAMPLES = 200
INTERP_ORDER = 0
QC_MAX_PLOT = 40

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "centerlines_aligned"), exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "masks_aligned"), exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "ostia_aligned"), exist_ok=True)
os.makedirs(os.path.join(OUT_DIR, "qc"), exist_ok=True)


# ======================================================
# UTILS
# ======================================================
def extract_id(path):
    name = os.path.basename(path)
    for pat in [
        r"^(.*)_centerline_rca\.vtp$",
        r"^(.*)_rca_mask\.nrrd$",
        r"^(.*)_ostium\.npy$",
    ]:
        m = re.match(pat, name)
        if m:
            return m.group(1)
    raise ValueError(f"ID non estraibile da: {name}")


def load_vtp_polyline(vtp_path):
    poly = pv.read(vtp_path)
    pts = np.asarray(poly.points, float)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] < 2:
        raise RuntimeError(f"Centerline RCA non valida: {vtp_path}")
    return pts


def save_vtp_polyline(points, out_path):
    poly = pv.PolyData(points)
    poly.lines = np.hstack(([len(points)], np.arange(len(points))))
    poly.save(out_path)


def polyline_arclength(pts):
    d = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    s = np.zeros(len(pts), float)
    s[1:] = np.cumsum(d)
    return s


def resample_polyline_by_arclength(pts, n):
    pts = np.asarray(pts, float)
    if len(pts) < 2:
        raise RuntimeError("Centerline troppo corta")

    s = polyline_arclength(pts)
    if s[-1] < 1e-9:
        return np.repeat(pts[:1], n, axis=0)

    s_new = np.linspace(0.0, s[-1], n)
    out = np.vstack([np.interp(s_new, s, pts[:, i]) for i in range(3)]).T
    return out


def maybe_flip_by_error(src, tgt):
    e1 = np.mean(np.linalg.norm(src - tgt, axis=1))
    e2 = np.mean(np.linalg.norm(src[::-1] - tgt, axis=1))
    return src if e1 <= e2 else src[::-1].copy()


# ======================================================
# NRRD GEOMETRY
# ======================================================
def nrrd_affine_from_header(hdr):
    origin = np.array(hdr.get("space origin", [0, 0, 0]), float)
    sd = hdr.get("space directions", None)

    if sd is None:
        sp = np.array(hdr.get("spacings", [1, 1, 1]), float)[:3]
        M = np.diag(sp)
        return origin, M

    cols = []
    for v in sd[:3]:
        if v is None:
            cols.append(np.array([0, 0, 0], float))
        else:
            cols.append(np.array(v, float))
    M = np.column_stack(cols)
    return origin, M


def phys_to_voxel(xyz, origin, M):
    Minv = np.linalg.pinv(M)
    xyz = np.asarray(xyz, float)
    return (xyz - origin[None, :]) @ Minv.T


def voxel_to_phys(ijk, origin, M):
    ijk = np.asarray(ijk, float)
    return origin[None, :] + ijk @ M.T


# ======================================================
# RIGID KABSCH WEIGHTED
# ======================================================
def rigid_kabsch_weighted(A, B, w=None):
    """
    (R @ A.T).T + t ~= B
    """
    if w is None:
        ca = A.mean(axis=0)
        cb = B.mean(axis=0)
        AA = A - ca
        BB = B - cb
        H = AA.T @ BB
    else:
        w = np.asarray(w, float).reshape(-1, 1)
        w = w / (np.sum(w) + 1e-12)

        ca = np.sum(w * A, axis=0)
        cb = np.sum(w * B, axis=0)

        AA = A - ca
        BB = B - cb

        H = (AA * w).T @ BB

    U, _, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T

    if np.linalg.det(R) < 0:
        Vt[-1, :] *= -1
        R = Vt.T @ U.T

    t = cb - (R @ ca)
    return R, t


def apply_rigid(points, R, t):
    return (R @ points.T).T + t


def mean_point_error(A, B):
    return float(np.mean(np.linalg.norm(A - B, axis=1)))


# ======================================================
# TEMPLATE SELECTION
# ======================================================
def choose_template(centerlines_resampled):
    centroids = np.array([cl.mean(axis=0) for cl in centerlines_resampled])
    med = np.median(centroids, axis=0)
    d = np.linalg.norm(centroids - med[None, :], axis=1)
    return int(np.argmin(d))


# ======================================================
# MASK RESAMPLING INTO TEMPLATE GRID
# ======================================================
def resample_mask_to_template_grid_rigid(
    in_vol,
    in_origin,
    in_M,
    out_shape,
    out_origin,
    out_M,
    R_in_to_out,
    t_in_to_out,
    order=0,
):
    ii, jj, kk = np.meshgrid(
        np.arange(out_shape[0], dtype=float),
        np.arange(out_shape[1], dtype=float),
        np.arange(out_shape[2], dtype=float),
        indexing="ij",
    )
    ijk_out = np.stack([ii, jj, kk], axis=-1).reshape(-1, 3)

    out_phys = voxel_to_phys(ijk_out, out_origin, out_M)
    in_phys = (R_in_to_out.T @ (out_phys - t_in_to_out[None, :]).T).T
    ijk_in = phys_to_voxel(in_phys, in_origin, in_M)

    coords = [ijk_in[:, 0], ijk_in[:, 1], ijk_in[:, 2]]
    sampled = map_coordinates(
        in_vol.astype(float),
        coords,
        order=order,
        mode="constant",
        cval=0.0
    )
    out_vol = sampled.reshape(out_shape)

    if order == 0:
        out_vol = (out_vol > 0.5).astype(np.uint8)

    return out_vol


# ======================================================
# QC
# ======================================================
def qc_overlay(template_cl, aligned_cls, out_path, max_plot=40):
    if len(aligned_cls) == 0:
        return

    idx = np.arange(len(aligned_cls))
    if len(aligned_cls) > max_plot:
        idx = np.linspace(0, len(aligned_cls) - 1, max_plot).round().astype(int)

    fig = plt.figure(figsize=(9, 7))
    ax = fig.add_subplot(111, projection="3d")

    ax.plot(template_cl[:, 0], template_cl[:, 1], template_cl[:, 2], linewidth=3)

    for i in idx:
        cl = aligned_cls[i]
        ax.plot(cl[:, 0], cl[:, 1], cl[:, 2], alpha=0.25)

    ax.set_title(f"RCA rigid alignment overlay (n={len(idx)})")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close(fig)


# ======================================================
# MAIN
# ======================================================
cl_paths = sorted(glob.glob(os.path.join(INPUT_DIR, CL_PATTERN)))
mask_paths = sorted(glob.glob(os.path.join(INPUT_DIR, MASK_PATTERN)))
ost_paths = sorted(glob.glob(os.path.join(INPUT_DIR, OST_PATTERN)))

if len(cl_paths) == 0 or len(mask_paths) == 0 or len(ost_paths) == 0:
    raise RuntimeError("File RCA mancanti")

cl_map = {extract_id(p): p for p in cl_paths}
mask_map = {extract_id(p): p for p in mask_paths}
ost_map = {extract_id(p): p for p in ost_paths}

ids = sorted(set(cl_map.keys()) & set(mask_map.keys()) & set(ost_map.keys()))
if len(ids) < 2:
    raise RuntimeError("Troppi pochi casi matched RCA")

# load + resample
centerlines = []
ostia = []
for sid in ids:
    cl = load_vtp_polyline(cl_map[sid])
    cl = resample_polyline_by_arclength(cl, N_SAMPLES)
    centerlines.append(cl)

    ost = np.load(ost_map[sid]).astype(float).reshape(3)
    ostia.append(ost)

# choose template
t_idx = choose_template(centerlines)
template_id = ids[t_idx]
template_cl = centerlines[t_idx].copy()
template_ost = ostia[t_idx].copy()

# template mask grid
tmpl_vol, tmpl_hdr = nrrd.read(mask_map[template_id])
tmpl_origin, tmpl_M = nrrd_affine_from_header(tmpl_hdr)
tmpl_shape = tuple(int(x) for x in tmpl_vol.shape)

# proximal weighting
s = np.linspace(0.0, 1.0, N_SAMPLES)
w_cl = np.exp(-4.0 * s)

rows = []
aligned_cls = []

for sid, cl, ost in zip(ids, centerlines, ostia):
    if sid == template_id:
        R = np.eye(3)
        t = np.zeros(3)
        cl_al = template_cl.copy()
        ost_al = template_ost.copy()
        err = 0.0
    else:
        cl_use = maybe_flip_by_error(cl, template_cl)

        # costruiamo punti con ostio + centerline
        A = np.vstack([ost[None, :], cl_use])
        B = np.vstack([template_ost[None, :], template_cl])

        w = np.concatenate([[10.0], w_cl])  # ostio molto pesato

        R, t = rigid_kabsch_weighted(A, B, w=w)

        cl_al = apply_rigid(cl_use, R, t)
        ost_al = apply_rigid(ost[None, :], R, t)[0]
        err = mean_point_error(cl_al, template_cl)

    aligned_cls.append(cl_al)

    save_vtp_polyline(
        cl_al,
        os.path.join(OUT_DIR, "centerlines_aligned", f"{sid}_centerline_rca_aligned.vtp")
    )

    np.save(
        os.path.join(OUT_DIR, "ostia_aligned", f"{sid}_ostium_aligned.npy"),
        ost_al
    )

    vol, hdr = nrrd.read(mask_map[sid])
    origin, M = nrrd_affine_from_header(hdr)

    out_vol = resample_mask_to_template_grid_rigid(
        in_vol=(vol > 0).astype(np.uint8),
        in_origin=origin,
        in_M=M,
        out_shape=tmpl_shape,
        out_origin=tmpl_origin,
        out_M=tmpl_M,
        R_in_to_out=R,
        t_in_to_out=t,
        order=INTERP_ORDER,
    )

    out_hdr = dict(tmpl_hdr)
    nrrd.write(
        os.path.join(OUT_DIR, "masks_aligned", f"{sid}_rca_mask_aligned.nrrd"),
        out_vol.astype(np.uint8),
        out_hdr
    )

    rows.append([
        sid, template_id, err,
        t[0], t[1], t[2],
        R[0,0], R[0,1], R[0,2],
        R[1,0], R[1,1], R[1,2],
        R[2,0], R[2,1], R[2,2],
    ])

qc_overlay(
    template_cl,
    aligned_cls,
    os.path.join(OUT_DIR, "qc", "overlay_rca.png"),
    max_plot=QC_MAX_PLOT
)

header = "ID,template_id,mean_point_err_mm,t_x,t_y,t_z,R00,R01,R02,R10,R11,R12,R20,R21,R22"
np.savetxt(
    os.path.join(OUT_DIR, "rigid_transforms_rca.csv"),
    np.array(rows, dtype=object),
    delimiter=",",
    fmt="%s",
    header=header,
    comments=""
)

print(f"[DONE] Template RCA: {template_id}")