import os
import re
import glob
import numpy as np
import nrrd
import pyvista as pv


# ======================================================
# SETTINGS
# ======================================================

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import AORTA_ALIGNED_RIGID_DIR, RCA_ALIGNED_RIGID_DIR, NORMALIZED_DIR  # noqa: E402

AORTA_IN = AORTA_ALIGNED_RIGID_DIR
RCA_IN   = RCA_ALIGNED_RIGID_DIR

OUT_DIR  = NORMALIZED_DIR

# percentile robusti
AORTA_PERCENTILE = 20
RCA_PERCENTILE   = 15

# punti finali
AORTA_N_POINTS = 200
RCA_N_POINTS   = 150

os.makedirs(OUT_DIR, exist_ok=True)

for p in [
    "aorta/centerlines",
    "aorta/masks",
    "rca/centerlines",
    "rca/masks",
    "rca/ostia"
]:
    os.makedirs(os.path.join(OUT_DIR,p),exist_ok=True)


# ======================================================
# UTILS
# ======================================================

def extract_id(path):

    name = os.path.basename(path)

    patterns = [
        r"^(.*)_centerline_aorta_aligned\.vtp$",
        r"^(.*)_aorta_mask_aligned\.nrrd$",
        r"^(.*)_centerline_rca_aligned\.vtp$",
        r"^(.*)_rca_mask_aligned\.nrrd$",
        r"^(.*)_ostium_aligned\.npy$"
    ]

    for pat in patterns:
        m = re.match(pat,name)
        if m:
            return m.group(1)

    raise ValueError(name)


def polyline_arclength(pts):

    d = np.linalg.norm(np.diff(pts,axis=0),axis=1)

    s = np.zeros(len(pts))
    s[1:] = np.cumsum(d)

    return s


def clip_polyline_by_length(pts,max_len):

    pts = np.asarray(pts)

    s = polyline_arclength(pts)

    if s[-1] <= max_len:
        return pts

    idx = np.searchsorted(s,max_len)

    p0 = pts[idx-1]
    p1 = pts[idx]

    s0 = s[idx-1]
    s1 = s[idx]

    a = (max_len-s0)/(s1-s0)

    plast = p0 + a*(p1-p0)

    return np.vstack([pts[:idx],plast])


def resample_polyline(pts,n):

    s = polyline_arclength(pts)

    s_new = np.linspace(0,s[-1],n)

    out = np.vstack([
        np.interp(s_new,s,pts[:,0]),
        np.interp(s_new,s,pts[:,1]),
        np.interp(s_new,s,pts[:,2])
    ]).T

    return out


def reconstruct_mask(mask,hdr,centerline,max_len):

    origin = np.array(hdr["space origin"])
    M = np.column_stack(hdr["space directions"][:3])

    vox = np.argwhere(mask>0)

    pts = origin + vox @ M.T

    s = polyline_arclength(centerline)

    d = np.linalg.norm(
        pts[:,None,:] - centerline[None,:,:],
        axis=2
    )

    idx = np.argmin(d,axis=1)

    keep = s[idx] <= max_len

    out = np.zeros(mask.shape,np.uint8)

    vox_keep = vox[keep]

    out[vox_keep[:,0],vox_keep[:,1],vox_keep[:,2]] = 1

    return out


def reorder_from_anchor(pts,anchor):

    d0 = np.linalg.norm(pts[0]-anchor)
    d1 = np.linalg.norm(pts[-1]-anchor)

    if d1 < d0:
        return pts[::-1]

    return pts


# ======================================================
# LOAD FILE MAPS
# ======================================================

aorta_cl = glob.glob(os.path.join(AORTA_IN,"centerlines_aligned","*_centerline_aorta_aligned.vtp"))
aorta_mask = glob.glob(os.path.join(AORTA_IN,"masks_aligned","*_aorta_mask_aligned.nrrd"))

rca_cl = glob.glob(os.path.join(RCA_IN,"centerlines_aligned","*_centerline_rca_aligned.vtp"))
rca_mask = glob.glob(os.path.join(RCA_IN,"masks_aligned","*_rca_mask_aligned.nrrd"))
rca_ost = glob.glob(os.path.join(RCA_IN,"ostia_aligned","*_ostium_aligned.npy"))

cl_map = {extract_id(p):p for p in aorta_cl}
mask_map = {extract_id(p):p for p in aorta_mask}

rca_cl_map = {extract_id(p):p for p in rca_cl}
rca_mask_map = {extract_id(p):p for p in rca_mask}
rca_ost_map = {extract_id(p):p for p in rca_ost}

ids = sorted(set(cl_map)&set(mask_map)&set(rca_cl_map)&set(rca_mask_map)&set(rca_ost_map))

print("cases:",len(ids))


# ======================================================
# COMPUTE LENGTHS
# ======================================================

aorta_lengths = []
rca_lengths = []

for sid in ids:

    cl = pv.read(cl_map[sid]).points
    aorta_lengths.append(polyline_arclength(cl)[-1])

    cl = pv.read(rca_cl_map[sid]).points
    rca_lengths.append(polyline_arclength(cl)[-1])


AORTA_LEN = np.percentile(aorta_lengths,AORTA_PERCENTILE)
RCA_LEN   = np.percentile(rca_lengths,RCA_PERCENTILE)

print("AORTA cut length:",AORTA_LEN)
print("RCA cut length:",RCA_LEN)


# ======================================================
# NORMALIZATION
# ======================================================

rows = []

for sid in ids:

    print("processing:",sid)

    cl_a = pv.read(cl_map[sid]).points
    cl_r = pv.read(rca_cl_map[sid]).points

    mask_a,hdr_a = nrrd.read(mask_map[sid])
    mask_r,hdr_r = nrrd.read(rca_mask_map[sid])

    ost = np.load(rca_ost_map[sid])

    cl_r = reorder_from_anchor(cl_r,ost)

    cl_r[0] = ost


    cl_a_clip = clip_polyline_by_length(cl_a,AORTA_LEN)
    cl_r_clip = clip_polyline_by_length(cl_r,RCA_LEN)


    cl_a_norm = resample_polyline(cl_a_clip,AORTA_N_POINTS)
    cl_r_norm = resample_polyline(cl_r_clip,RCA_N_POINTS)


    poly = pv.PolyData(cl_a_norm)
    poly.lines = np.hstack(([len(cl_a_norm)],np.arange(len(cl_a_norm))))
    poly.save(os.path.join(OUT_DIR,"aorta","centerlines",f"{sid}_centerline_aorta_normalized.vtp"))


    poly = pv.PolyData(cl_r_norm)
    poly.lines = np.hstack(([len(cl_r_norm)],np.arange(len(cl_r_norm))))
    poly.save(os.path.join(OUT_DIR,"rca","centerlines",f"{sid}_centerline_rca_normalized.vtp"))


    mask_new = reconstruct_mask(mask_a,hdr_a,cl_a_clip,AORTA_LEN)

    nrrd.write(
        os.path.join(OUT_DIR,"aorta","masks",f"{sid}_aorta_mask_normalized.nrrd"),
        mask_new,
        hdr_a
    )


    mask_new = reconstruct_mask(mask_r,hdr_r,cl_r_clip,RCA_LEN)

    nrrd.write(
        os.path.join(OUT_DIR,"rca","masks",f"{sid}_rca_mask_normalized.nrrd"),
        mask_new,
        hdr_r
    )


    np.save(
        os.path.join(OUT_DIR,"rca","ostia",f"{sid}_ostium_normalized.npy"),
        cl_r_norm[0]
    )


    rows.append([
        sid,
        polyline_arclength(cl_a)[-1],
        polyline_arclength(cl_r)[-1]
    ])


np.savetxt(
    os.path.join(OUT_DIR,"normalization_summary.csv"),
    np.array(rows,dtype=object),
    delimiter=",",
    fmt="%s",
    header="ID,aorta_length,rca_length",
    comments=""
)

print("Normalization complete")