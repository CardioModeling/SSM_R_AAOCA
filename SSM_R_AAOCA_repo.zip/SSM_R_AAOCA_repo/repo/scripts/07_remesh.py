import os
import re
import json
import glob
import numpy as np
import pyvista as pv
import pyacvd


# ======================================================
# SETTINGS
# ======================================================
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import NORMALIZED_DIR, MESH_DIR, REMESH_DIR  # noqa: E402

OUT_DIR = REMESH_DIR

AORTA_CL_DIR = os.path.join(NORMALIZED_DIR, "aorta", "centerlines")
RCA_CL_DIR   = os.path.join(NORMALIZED_DIR, "rca",   "centerlines")

AORTA_MESH_DIR = os.path.join(MESH_DIR, "aorta")
RCA_MESH_DIR   = os.path.join(MESH_DIR, "rca")

AORTA_OUT = os.path.join(OUT_DIR, "aorta")
RCA_OUT   = os.path.join(OUT_DIR, "rca")

os.makedirs(AORTA_OUT, exist_ok=True)
os.makedirs(RCA_OUT,   exist_ok=True)

AORTA_TARGET_POINTS = 5000
RCA_TARGET_POINTS   = 2000

AORTA_CL_POINTS = 200
RCA_CL_POINTS   = 150


# ======================================================
# UTILS — centerline
# ======================================================
def extract_id_from_name(name: str) -> str:
    patterns = [
        r"^(.*)_centerline_aorta_normalized\.vtp$",
        r"^(.*)_centerline_rca_normalized\.vtp$",
        r"^(.*)\.vtk$",
    ]
    for pat in patterns:
        m = re.match(pat, name)
        if m:
            return m.group(1)
    raise ValueError(f"Impossibile estrarre ID da {name}")


def load_polyline(path: str) -> np.ndarray:
    poly = pv.read(path)
    pts  = np.asarray(poly.points, dtype=float)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] < 2:
        raise RuntimeError(f"Polyline non valida: {path}")
    return pts


def polyline_arclength(pts: np.ndarray) -> np.ndarray:
    d = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    s = np.zeros(len(pts), dtype=float)
    s[1:] = np.cumsum(d)
    return s


def resample_polyline(pts: np.ndarray, n: int) -> np.ndarray:
    s = polyline_arclength(pts)
    if s[-1] < 1e-9:
        return np.repeat(pts[:1], n, axis=0)
    s_new = np.linspace(0.0, s[-1], n)
    out   = np.vstack([np.interp(s_new, s, pts[:, i]) for i in range(3)]).T
    return out


def choose_common_template(case_ids, aorta_cl_map, rca_cl_map) -> str:
    vecs      = []
    valid_ids = []
    for sid in case_ids:
        try:
            a_cl = resample_polyline(load_polyline(aorta_cl_map[sid]), AORTA_CL_POINTS)
            r_cl = resample_polyline(load_polyline(rca_cl_map[sid]),   RCA_CL_POINTS)
            vecs.append(np.concatenate([a_cl.ravel(), r_cl.ravel()]))
            valid_ids.append(sid)
        except Exception:
            continue
    if len(valid_ids) < 2:
        raise RuntimeError("Troppi pochi casi validi per scegliere il template comune")
    X   = np.vstack(vecs)
    med = np.median(X, axis=0)
    d   = np.linalg.norm(X - med[None, :], axis=1)
    return valid_ids[int(np.argmin(d))]


# ======================================================
# FIX NORMALI — robusto per mesh post-pyacvd
# ======================================================
def _remove_nm_edge_faces(mesh: pv.PolyData) -> pv.PolyData:

    nm = mesh.extract_feature_edges(
        boundary_edges=False,
        non_manifold_edges=True,
        feature_edges=False,
        manifold_edges=False,
    )
    if nm.n_points == 0:
        return mesh  # nessun non-manifold, niente da fare

    nm_coords = set(
        map(tuple, np.round(np.asarray(nm.points, float), decimals=4))
    )

    pts   = np.asarray(mesh.points, float)
    faces = mesh.faces.reshape(-1, 4)

    keep = []
    for row in faces:
        touches = any(
            tuple(np.round(pts[int(row[k])], decimals=4)) in nm_coords
            for k in (1, 2, 3)
        )
        if not touches:
            keep.append(row)

    if len(keep) == len(faces):
        return mesh

    new_faces = np.array(keep, dtype=np.int64).ravel()
    return pv.PolyData(pts, new_faces).clean().triangulate()


def fix_normals(mesh: pv.PolyData) -> pv.PolyData:

    # passo 1 — rimuovi eventuali facce non-manifold residue
    mesh = _remove_nm_edge_faces(mesh)

    # passo 2 — orientazione coerente
    mesh = mesh.compute_normals(
        cell_normals=True,
        point_normals=True,
        consistent_normals=True,
        auto_orient_normals=True,
        non_manifold_traversal=False,
        inplace=False,
    )

    # passo 3 — sanity check volume
    try:
        vol = mesh.volume
        if np.isfinite(vol) and vol < 0.0:
            mesh.flip_normals()
            mesh = mesh.compute_normals(
                cell_normals=True,
                point_normals=True,
                consistent_normals=False,
                auto_orient_normals=False,
                inplace=False,
            )
    except Exception:
        pass

    return mesh


# ======================================================
# REMESH
# ======================================================
def remesh_uniform(mesh: pv.PolyData, target_points: int) -> pv.PolyData:
    
    mesh = mesh.triangulate().clean()

    cluster = pyacvd.Clustering(mesh)
    cluster.subdivide(2)
    cluster.cluster(target_points)
    remeshed = cluster.create_mesh()

    remeshed = remeshed.clean().triangulate()

    # fix normali robusto — sostituisce compute_normals(auto_orient_normals=True)
    remeshed = fix_normals(remeshed)

    return remeshed


# ======================================================
# MAIN
# ======================================================
if __name__ == "__main__":
    aorta_cl_paths   = sorted(glob.glob(os.path.join(AORTA_CL_DIR, "*_centerline_aorta_normalized.vtp")))
    rca_cl_paths     = sorted(glob.glob(os.path.join(RCA_CL_DIR,   "*_centerline_rca_normalized.vtp")))
    aorta_mesh_paths = sorted(glob.glob(os.path.join(AORTA_MESH_DIR, "*.vtk")))
    rca_mesh_paths   = sorted(glob.glob(os.path.join(RCA_MESH_DIR,   "*.vtk")))

    aorta_cl_map   = {extract_id_from_name(os.path.basename(p)): p for p in aorta_cl_paths}
    rca_cl_map     = {extract_id_from_name(os.path.basename(p)): p for p in rca_cl_paths}
    aorta_mesh_map = {extract_id_from_name(os.path.basename(p)): p for p in aorta_mesh_paths}
    rca_mesh_map   = {extract_id_from_name(os.path.basename(p)): p for p in rca_mesh_paths}

    case_ids = sorted(
        set(aorta_cl_map)   &
        set(rca_cl_map)     &
        set(aorta_mesh_map) &
        set(rca_mesh_map)
    )

    if len(case_ids) < 2:
        raise RuntimeError("Troppi pochi casi matched per pipeline congiunta")

    template_id = choose_common_template(case_ids, aorta_cl_map, rca_cl_map)
    print(f"[TEMPLATE] common template ID = {template_id}")

    for sid in case_ids:
        try:
            a_mesh = pv.read(aorta_mesh_map[sid])
            a_rem  = remesh_uniform(a_mesh, AORTA_TARGET_POINTS)
            a_rem.save(os.path.join(AORTA_OUT, f"{sid}.vtk"))

            r_mesh = pv.read(rca_mesh_map[sid])
            r_rem  = remesh_uniform(r_mesh, RCA_TARGET_POINTS)
            r_rem.save(os.path.join(RCA_OUT, f"{sid}.vtk"))

            print(f"[OK] {sid} | aorta_pts={a_rem.n_points} | rca_pts={r_rem.n_points}")
        except Exception as e:
            print(f"[SKIP] {sid}: {e}")

    info = {
        "template_id":        template_id,
        "aorta_target_points": AORTA_TARGET_POINTS,
        "rca_target_points":   RCA_TARGET_POINTS,
        "aorta_cl_points":     AORTA_CL_POINTS,
        "rca_cl_points":       RCA_CL_POINTS,
    }

    with open(os.path.join(OUT_DIR, "template_info.json"), "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2)