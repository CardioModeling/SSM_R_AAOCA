import os
import json
import glob
import numpy as np
import pyvista as pv

from pycpd import DeformableRegistration


# ======================================================
# SETTINGS
# ======================================================
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import REMESH_DIR, RCA_ALIGNED_RIGID_DIR, REGISTERED_DIR  # noqa: E402

# ── Input: meshes già remeshate (topologia uniforme) ──
AORTA_IN   = os.path.join(REMESH_DIR, "aorta")
RCA_IN     = os.path.join(REMESH_DIR, "rca")

# ── Input: ostia allineati dal rigid alignment (stage 4) ──
# Usa i centreline e gli ostia già allineati rigidamente con Kabsch
RCA_RIGID_DIR = RCA_ALIGNED_RIGID_DIR
OSTIA_ALIGNED_DIR = os.path.join(RCA_RIGID_DIR, "ostia_aligned")
CL_ALIGNED_DIR    = os.path.join(RCA_RIGID_DIR, "centerlines_aligned")

# ── Output ──
OUT_DIR    = REGISTERED_DIR
AORTA_OUT  = os.path.join(OUT_DIR, "aorta")
RCA_OUT    = os.path.join(OUT_DIR, "rca")

os.makedirs(AORTA_OUT, exist_ok=True)
os.makedirs(RCA_OUT,   exist_ok=True)

INFO_JSON = os.path.join(REMESH_DIR, "template_info.json")

# CPD parameters
DEFORM_MAX_ITERS = 150
DEFORM_TOL       = 1e-5
DEFORM_ALPHA     = 2.0   # regularisation weight
DEFORM_BETA      = 2.5   # Gaussian kernel width (mm)


# ======================================================
# UTILS
# ======================================================
def load_mesh(path: str) -> pv.PolyData:
    mesh = pv.read(path).triangulate().clean()
    if mesh.n_points < 10:
        raise RuntimeError(f"Mesh troppo piccola: {path}")
    return mesh


def load_ostium(sid: str) -> np.ndarray:
    """Load aligned ostium point for a given subject ID."""
    path = os.path.join(OSTIA_ALIGNED_DIR, f"{sid}_ostium_aligned.npy")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Ostium allineato non trovato: {path}")
    return np.load(path).astype(float).reshape(3)


def load_centerline(sid: str) -> np.ndarray:
    """Load aligned centreline for a given subject ID."""
    import pyvista as pv
    path = os.path.join(CL_ALIGNED_DIR, f"{sid}_centerline_rca_aligned.vtp")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Centreline allineata non trovata: {path}")
    poly = pv.read(path)
    return np.asarray(poly.points, float)


def rigid_align_with_ostium(template_pts: np.ndarray,
                             subject_pts: np.ndarray,
                             template_ostium: np.ndarray,
                             subject_ostium: np.ndarray) -> np.ndarray:
    
    from numpy.linalg import svd

    def kabsch_weighted(A, B, w):
        w = np.array(w, float)
        w /= w.sum()
        ca = (w[:, None] * A).sum(0)
        cb = (w[:, None] * B).sum(0)
        AA = A - ca
        BB = B - cb
        H = (AA * w[:, None]).T @ BB
        U, _, Vt = svd(H)
        R = Vt.T @ U.T
        if np.linalg.det(R) < 0:
            Vt[-1] *= -1
            R = Vt.T @ U.T
        t = cb - R @ ca
        return R, t

    # costruisce insieme di punti: ostio (peso alto) + mesh points
    n = len(template_pts)
    w_pts = np.ones(n)
    # decadimento esponenziale dalla prima alla ultima riga
    # (assumiamo che i vertici siano circa ordinati prossimale→distale dopo remesh)
    idx = np.arange(n, dtype=float)
    w_pts = np.exp(-4.0 * idx / n)

    A = np.vstack([subject_ostium[None, :], subject_pts])
    B = np.vstack([template_ostium[None, :], template_pts])
    w = np.concatenate([[10.0], w_pts])

    R, t = kabsch_weighted(A, B, w)

    aligned = (R @ subject_pts.T).T + t
    ost_al  = R @ subject_ostium + t

    # ── flip check lungo asse principale ──────────────────────────────────
    # Se l'ostio allineato è più lontano dall'ostio template che dall'estremità
    # opposta → la mesh è capovolta → inverte lungo il primo asse di varianza
    dist_ost  = np.linalg.norm(ost_al       - template_ostium)
    # stima estremo distale del template come centroide dei 5% più distanti
    dists_from_ost = np.linalg.norm(template_pts - template_ostium, axis=1)
    distal_mask = dists_from_ost > np.percentile(dists_from_ost, 95)
    template_distal = template_pts[distal_mask].mean(axis=0)

    dist_distal = np.linalg.norm(ost_al - template_distal)

    if dist_distal < dist_ost:
        # ostio allineato è più vicino all'estremità distale → flip
        # riflette il soggetto attorno al baricentro lungo l'asse principale
        pca_axis = np.linalg.svd(subject_pts - subject_pts.mean(0), full_matrices=False)[2][0]
        center   = subject_pts.mean(0)
        subject_pts_flipped = subject_pts - 2 * np.outer(
            (subject_pts - center) @ pca_axis, pca_axis)
        ost_flipped = subject_ostium - 2 * ((subject_ostium - center) @ pca_axis) * pca_axis

        R, t = kabsch_weighted(
            np.vstack([ost_flipped[None, :], subject_pts_flipped]),
            B, w)
        aligned = (R @ subject_pts_flipped.T).T + t
        print(f"    [flip corrected] dist_ost={dist_ost:.1f} dist_distal={dist_distal:.1f}")

    return aligned


def deform_template_to_subject(template_pts: np.ndarray,
                                subject_aligned_pts: np.ndarray) -> np.ndarray:
    """
    CPD deformabile: template → soggetto già pre-allineato rigidamente.
    NON usa il rigid CPD interno per evitare flip.
    """
    reg = DeformableRegistration(
        X=subject_aligned_pts,
        Y=template_pts.copy(),
        alpha=DEFORM_ALPHA,
        beta=DEFORM_BETA,
        max_iterations=DEFORM_MAX_ITERS,
        tolerance=DEFORM_TOL
    )
    TY, _ = reg.register()
    return TY


def resample_mesh_to_n_points(mesh: pv.PolyData, n_target: int) -> pv.PolyData:
    
    if mesh.n_points == n_target:
        return mesh
    try:
        import pyacvd
        clus = pyacvd.Clustering(mesh)
        clus.cluster(n_target)
        remeshed = clus.create_mesh()
        print(f"    [resample] {mesh.n_points} → {remeshed.n_points} pts")
        return remeshed.clean().triangulate()
    except Exception as e:
        # Fallback: subsample/supersample points directly (no topology fix)
        print(f"    [resample fallback] {mesh.n_points} → {n_target} pts ({e})")
        pts = np.asarray(mesh.points, float)
        if mesh.n_points > n_target:
            idx = np.linspace(0, mesh.n_points - 1, n_target).round().astype(int)
        else:
            idx = np.round(np.linspace(0, mesh.n_points - 1, n_target)).astype(int)
        new_pts = pts[idx]
        return pv.PolyData(new_pts)


def register_structure(template_mesh: pv.PolyData,
                        subject_mesh: pv.PolyData,
                        template_ostium: np.ndarray = None,
                        subject_ostium: np.ndarray  = None) -> pv.PolyData:
    # ensure same vertex count as template
    subject_mesh = resample_mesh_to_n_points(subject_mesh, template_mesh.n_points)

    template_pts = np.asarray(template_mesh.points, dtype=float)
    subject_pts  = np.asarray(subject_mesh.points,  dtype=float)

    if template_ostium is not None and subject_ostium is not None:
        # RCA: rigid pre-align con anchor ostio + flip check
        subject_prealigned = rigid_align_with_ostium(
            template_pts, subject_pts,
            template_ostium, subject_ostium)
    else:
        # Aorta: rigid CPD standard (struttura compatta, flip non è un problema)
        from pycpd import RigidRegistration
        reg = RigidRegistration(X=template_pts, Y=subject_pts, max_iterations=100)
        subject_prealigned, _ = reg.register()

    # CPD deformabile senza rigid interno
    deformed_pts = deform_template_to_subject(template_pts, subject_prealigned)

    out = pv.PolyData(deformed_pts, template_mesh.faces.copy())
    out = out.clean().triangulate()
    out = out.compute_normals(auto_orient_normals=True, inplace=False)
    return out


# ======================================================
# MAIN
# ======================================================
if __name__ == "__main__":
    with open(INFO_JSON, "r", encoding="utf-8") as f:
        info = json.load(f)
    template_id = info["template_id"]

    aorta_paths = sorted(glob.glob(os.path.join(AORTA_IN, "*.vtk")))
    rca_paths   = sorted(glob.glob(os.path.join(RCA_IN,   "*.vtk")))

    aorta_map = {os.path.splitext(os.path.basename(p))[0]: p for p in aorta_paths}
    rca_map   = {os.path.splitext(os.path.basename(p))[0]: p for p in rca_paths}

    case_ids = sorted(set(aorta_map) & set(rca_map))
    if len(case_ids) < 2:
        raise RuntimeError("Troppi pochi casi")
    if template_id not in case_ids:
        raise RuntimeError(f"Template {template_id} non trovato")

    # ── load templates ────────────────────────────────────────────────────────
    template_aorta = load_mesh(aorta_map[template_id])
    template_rca   = load_mesh(rca_map[template_id])

    try:
        template_ostium = load_ostium(template_id)
    except FileNotFoundError:
        print(f"[WARN] Ostio template non trovato — RCA registrata senza anchor")
        template_ostium = None

    # template saved as-is
    template_aorta.save(os.path.join(AORTA_OUT, f"{template_id}.vtk"))
    template_rca.save(  os.path.join(RCA_OUT,   f"{template_id}.vtk"))
    print(f"[TEMPLATE] {template_id} | aorta={template_aorta.n_points}pts | rca={template_rca.n_points}pts")

    # ── register all subjects ─────────────────────────────────────────────────
    errors = []
    for sid in case_ids:
        if sid == template_id:
            continue
        try:
            # aorta
            subj_aorta = load_mesh(aorta_map[sid])
            reg_aorta  = register_structure(template_aorta, subj_aorta)
            reg_aorta.save(os.path.join(AORTA_OUT, f"{sid}.vtk"))

            # rca — con ostio anchor se disponibile
            subj_rca = load_mesh(rca_map[sid])
            try:
                subj_ostium = load_ostium(sid)
            except FileNotFoundError:
                print(f"  [WARN] {sid}: ostio non trovato, RCA senza anchor")
                subj_ostium = None

            reg_rca = register_structure(
                template_rca, subj_rca,
                template_ostium=template_ostium,
                subject_ostium=subj_ostium)
            reg_rca.save(os.path.join(RCA_OUT, f"{sid}.vtk"))

            # QC: distanza media tra template e mesh registrata (deve essere < 2mm)
            err = float(np.mean(np.linalg.norm(
                np.asarray(reg_rca.points) - np.asarray(template_rca.points), axis=1)))
            errors.append((sid, err))

            status = "OK" if err < 3.0 else "WARN high error"
            print(f"[{status}] {sid} | aorta={reg_aorta.n_points}pts | rca={reg_rca.n_points}pts | rca_err={err:.2f}mm")

        except Exception as e:
            print(f"[SKIP] {sid}: {e}")

    # ── summary ───────────────────────────────────────────────────────────────
    if errors:
        errs = [e for _, e in errors]
        print(f"\n[SUMMARY] RCA registration errors: "
              f"mean={np.mean(errs):.2f}mm  max={np.max(errs):.2f}mm  "
              f"n_warn={sum(1 for e in errs if e >= 3.0)}/{len(errs)}")
        high_err = [(sid, e) for sid, e in errors if e >= 3.0]
        if high_err:
            print("  High-error cases (check manually):")
            for sid, e in sorted(high_err, key=lambda x: -x[1]):
                print(f"    {sid}: {e:.2f}mm")