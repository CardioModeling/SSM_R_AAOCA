import os
import re
import glob
import numpy as np
import nrrd
import pyvista as pv
from skimage import measure


# ======================================================
# SETTINGS
# ======================================================
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import NORMALIZED_DIR, MESH_DIR  # noqa: E402

OUT_DIR = MESH_DIR

AORTA_MASK_DIR = os.path.join(NORMALIZED_DIR, "aorta", "masks")
RCA_MASK_DIR   = os.path.join(NORMALIZED_DIR, "rca",   "masks")

AORTA_OUT = os.path.join(OUT_DIR, "aorta")
RCA_OUT   = os.path.join(OUT_DIR, "rca")

os.makedirs(AORTA_OUT, exist_ok=True)
os.makedirs(RCA_OUT,   exist_ok=True)

AORTA_PATTERN = "*_aorta_mask_normalized.nrrd"
RCA_PATTERN   = "*_rca_mask_normalized.nrrd"

# ── riparazione ──────────────────────────────────────
# FILL_HOLES_SIZE alto perche i fori grandi alle estremita vengono
# gestiti prima da cap_boundary_holes; qui serve solo per fori piccoli.
FILL_HOLES_SIZE   = 500.0
SMOOTH_ITER       = 30
SMOOTH_PASS_BAND  = 0.1
DECIMATE_FRACTION = 0.01


# ======================================================
# UTILS — geometria NRRD
# ======================================================
def extract_id(path: str) -> str:
    name = os.path.basename(path)
    for pat in [
        r"^(.*)_aorta_mask_normalized\.nrrd$",
        r"^(.*)_rca_mask_normalized\.nrrd$",
    ]:
        m = re.match(pat, name)
        if m:
            return m.group(1)
    raise ValueError(f"Impossibile estrarre ID da {name}")


def nrrd_affine_from_header(hdr):
    origin = np.array(hdr.get("space origin", [0, 0, 0]), dtype=float)
    sd = hdr.get("space directions", None)
    if sd is None:
        sp = np.array(hdr.get("spacings", [1, 1, 1]), dtype=float)[:3]
        return origin, np.diag(sp)
    cols = []
    for v in sd[:3]:
        cols.append(np.zeros(3, float) if v is None else np.array(v, float))
    return origin, np.column_stack(cols)


def voxel_to_phys(ijk, origin, M):
    return origin[None, :] + np.asarray(ijk, float) @ M.T


# ======================================================
# ISOSURFACE
# ======================================================
def polydata_from_binary_mask(vol_u8: np.ndarray,
                               origin: np.ndarray,
                               M: np.ndarray) -> pv.PolyData:
    if np.count_nonzero(vol_u8) == 0:
        raise RuntimeError("Maschera vuota")

    verts, faces, _, _ = measure.marching_cubes(vol_u8, level=0.5)
    verts_phys = voxel_to_phys(verts, origin, M)

    faces_pv = np.hstack([
        np.full((faces.shape[0], 1), 3, dtype=np.int64),
        faces.astype(np.int64)
    ])
    return pv.PolyData(verts_phys, faces_pv)


# ======================================================
# CHIUSURA MESH
# ======================================================

def _order_loop_points(boundary_cc: pv.PolyData, mask: np.ndarray):
    """
    Ordina i punti di un singolo boundary loop seguendo la connettivita
    degli edge. Restituisce array (N, 3) oppure None se fallisce.
    """
    try:
        pts_all   = np.asarray(boundary_cc.points, float)
        global_idx = np.where(mask)[0]
        g2l = {int(g): l for l, g in enumerate(global_idx)}

        adj = {i: [] for i in range(len(global_idx))}
        lines = boundary_cc.lines
        i = 0
        while i < len(lines):
            seg_len = int(lines[i])
            seg = lines[i + 1: i + 1 + seg_len]
            i += 1 + seg_len
            for k in range(len(seg) - 1):
                a, b = int(seg[k]), int(seg[k + 1])
                if a in g2l and b in g2l:
                    la, lb = g2l[a], g2l[b]
                    if lb not in adj[la]:
                        adj[la].append(lb)
                    if la not in adj[lb]:
                        adj[lb].append(la)

        visited = [False] * len(global_idx)
        order   = [0]
        visited[0] = True
        for _ in range(len(global_idx) - 1):
            current = order[-1]
            moved   = False
            for nb in adj[current]:
                if not visited[nb]:
                    order.append(nb)
                    visited[nb] = True
                    moved = True
                    break
            if not moved:
                break

        return pts_all[global_idx[order]]
    except Exception:
        return None


def cap_boundary_holes(mesh: pv.PolyData) -> pv.PolyData:

    mesh = mesh.triangulate().clean()

    boundary = mesh.extract_feature_edges(
        boundary_edges=True,
        non_manifold_edges=False,
        feature_edges=False,
        manifold_edges=False,
    )
    if boundary.n_points == 0:
        return mesh  # gia chiusa

    boundary_cc = boundary.connectivity(largest=False)
    if "RegionId" not in boundary_cc.point_data:
        return mesh

    region_ids = boundary_cc.point_data["RegionId"]
    n_regions  = int(region_ids.max()) + 1

    new_points = list(np.asarray(mesh.points, float))
    new_faces  = []

    faces_arr = mesh.faces.reshape(-1, 4)
    for row in faces_arr:
        new_faces.extend([3, int(row[1]), int(row[2]), int(row[3])])

    for rid in range(n_regions):
        mask = region_ids == rid

        loop_pts = _order_loop_points(boundary_cc, mask)
        if loop_pts is None or len(loop_pts) < 3:
            # fallback non ordinato
            loop_pts = np.asarray(boundary_cc.points[mask], float)
        if len(loop_pts) < 3:
            continue

        centroid = loop_pts.mean(axis=0)
        c_idx    = len(new_points)
        new_points.append(centroid.tolist())

        base_idx = len(new_points)
        n        = len(loop_pts)
        for pt in loop_pts:
            new_points.append(pt.tolist())

        # orientazione della patch: calcola la normale media della mesh
        # originale nel punto più vicino al centroide del loop,
        # e usa quel verso per determinare l'ordine di avvolgimento
        # (CW vs CCW) delle facce della patch.
        if mesh.n_cells > 0:
            try:
                mesh_with_normals = mesh.compute_normals(
                    cell_normals=True, point_normals=False,
                    consistent_normals=True, inplace=False
                )
                pts_mesh = np.asarray(mesh_with_normals.points, float)
                normals  = np.asarray(
                    mesh_with_normals.cell_data.get(
                        "Normals",
                        mesh_with_normals.cell_data.get("CellNormals", None)
                    ), float
                ) if mesh_with_normals.n_cells > 0 else None

                if normals is not None and len(normals) > 0:
                    # trova la cella più vicina al centroide
                    cell_centers = np.asarray(
                        mesh_with_normals.cell_centers().points, float
                    )
                    d_cells = np.linalg.norm(cell_centers - centroid[None, :], axis=1)
                    nearest_cell = int(np.argmin(d_cells))
                    ref_normal = normals[nearest_cell]

                    # normale della patch (ordine CCW: c→i0→i1)
                    if n >= 3:
                        v1 = loop_pts[1] - loop_pts[0]
                        v2 = loop_pts[2] - loop_pts[0]
                        patch_normal = np.cross(v1, v2)
                        pn_norm = np.linalg.norm(patch_normal)
                        if pn_norm > 1e-9:
                            patch_normal /= pn_norm
                            # se patch_normal punta nella stessa direzione
                            # della normale di riferimento, invertire l'ordine
                            # (la patch deve chiudere verso l'interno)
                            if np.dot(patch_normal, ref_normal) > 0:
                                loop_pts = loop_pts[::-1]
            except Exception:
                pass  # se fallisce usiamo l'ordine originale

        for i in range(n):
            i0 = base_idx + i
            i1 = base_idx + (i + 1) % n
            new_faces.extend([3, c_idx, i0, i1])

    capped = pv.PolyData(
        np.array(new_points, dtype=float),
        np.array(new_faces,  dtype=np.int64)
    )
    return capped.clean().triangulate()


def remove_duplicate_faces(mesh: pv.PolyData) -> pv.PolyData:
    """
    Rimuove facce duplicate che causano edge non-manifold con boundary_pts=0.
    Le facce duplicate nascono quando marching cubes genera triangoli
    sovrapposti ai bordi del volume, o quando cap_boundary_holes
    aggiunge patch su zone gia parzialmente chiuse.
    """
    try:
        faces = mesh.faces.reshape(-1, 4)  # [3, i, j, k]
        seen  = set()
        keep  = []
        for row in faces:
            key = tuple(sorted([int(row[1]), int(row[2]), int(row[3])]))
            if key not in seen:
                seen.add(key)
                keep.append(row)
        if len(keep) == len(faces):
            return mesh  # nessun duplicato trovato
        new_faces = np.array(keep, dtype=np.int64).ravel()
        cleaned   = pv.PolyData(np.asarray(mesh.points, float), new_faces)
        return cleaned.clean().triangulate()
    except Exception:
        return mesh


def repair_non_manifold(mesh: pv.PolyData) -> pv.PolyData:

    mesh = remove_duplicate_faces(mesh)
    nm = mesh.extract_feature_edges(
        boundary_edges=False,
        non_manifold_edges=True,
        feature_edges=False,
        manifold_edges=False,
    )
    if nm.n_points == 0:
        return mesh
    return mesh.connectivity(largest=True).triangulate().clean()


def _remove_nm_edge_faces(mesh: pv.PolyData) -> pv.PolyData:

    nm = mesh.extract_feature_edges(
        boundary_edges=False,
        non_manifold_edges=True,
        feature_edges=False,
        manifold_edges=False,
    )
    if nm.n_points == 0:
        return mesh

    # coordinate dei punti non-manifold
    nm_pts_coords = set(
        map(tuple, np.round(np.asarray(nm.points, float), decimals=4))
    )

    pts   = np.asarray(mesh.points, float)
    faces = mesh.faces.reshape(-1, 4)

    keep = []
    n_removed = 0
    for row in faces:
        i0, i1, i2 = int(row[1]), int(row[2]), int(row[3])
        # controlla se uno qualsiasi dei 3 vertici e un punto non-manifold
        touches_nm = any(
            tuple(np.round(pts[idx], decimals=4)) in nm_pts_coords
            for idx in (i0, i1, i2)
        )
        if touches_nm:
            n_removed += 1
        else:
            keep.append(row)

    if n_removed == 0:
        return mesh

    new_faces = np.array(keep, dtype=np.int64).ravel()
    result = pv.PolyData(pts, new_faces).clean().triangulate()
    return result


def fix_normals(mesh: pv.PolyData) -> pv.PolyData:

    # passo 1 — rimuovi facce che bloccano la propagazione
    mesh_clean = _remove_nm_edge_faces(mesh)

    # passo 2 — consistent_normals sulla mesh pulita
    mesh_clean = mesh_clean.compute_normals(
        cell_normals=True,
        point_normals=True,
        consistent_normals=True,
        auto_orient_normals=True,
        non_manifold_traversal=False,
        inplace=False,
    )

    # passo 3 — sanity check volume
    try:
        vol = mesh_clean.volume
        if np.isfinite(vol) and vol < 0.0:
            mesh_clean.flip_normals()
            mesh_clean = mesh_clean.compute_normals(
                cell_normals=True, point_normals=True,
                consistent_normals=False, auto_orient_normals=False,
                inplace=False,
            )
    except Exception:
        pass

    return mesh_clean


def _count_boundary_pts(mesh: pv.PolyData) -> int:
    try:
        b = mesh.extract_feature_edges(
            boundary_edges=True,
            non_manifold_edges=False,
            feature_edges=False,
            manifold_edges=False,
        )
        return int(b.n_points)
    except Exception:
        return -1


def is_watertight(mesh: pv.PolyData) -> bool:
    """
    Watertight = nessun boundary edge + nessun non-manifold edge + volume > 0.
    """
    boundary = mesh.extract_feature_edges(
        boundary_edges=True,
        non_manifold_edges=False,
        feature_edges=False,
        manifold_edges=False,
    )
    nm = mesh.extract_feature_edges(
        boundary_edges=False,
        non_manifold_edges=True,
        feature_edges=False,
        manifold_edges=False,
    )
    if boundary.n_points > 0 or nm.n_points > 0:
        return False
    try:
        return np.isfinite(mesh.volume) and mesh.volume > 0.0
    except Exception:
        return False


# ======================================================
# PIPELINE COMPLETA DI PULIZIA
# ======================================================
def clean_surface(mesh: pv.PolyData, sid: str = "") -> pv.PolyData:
    

    # 1 — pulizia base + rimozione facce duplicate
    #     (causa principale di boundary_pts=0 con mesh non watertight)
    mesh = mesh.clean().triangulate()
    mesh = remove_duplicate_faces(mesh)
    mesh = mesh.clean().triangulate()

    # 2 — chiude bordi aperti grandi (estremita troncate aorta/RCA)
    mesh = cap_boundary_holes(mesh)

    # 3 — orienta normali coerentemente dopo il cap
    #     (risolve il problema viola/giallo in Slicer)
    mesh = fix_normals(mesh)

    # 4 — fill_holes per fori residui piccoli
    try:
        mesh = mesh.fill_holes(FILL_HOLES_SIZE).triangulate().clean()
    except Exception:
        pass

    # 5 — riparazione non-manifold
    mesh = repair_non_manifold(mesh)

    # 6 — secondo tentativo se ancora aperta
    if not is_watertight(mesh):
        mesh = cap_boundary_holes(mesh)
        mesh = mesh.triangulate().clean()
        mesh = repair_non_manifold(mesh)
        mesh = fix_normals(mesh)

    # 7 — smoothing (non tocca le normali, le ricalcoliamo dopo)
    mesh = mesh.smooth_taubin(n_iter=SMOOTH_ITER, pass_band=SMOOTH_PASS_BAND)

    # 7b — il smooth taubin puo creare non-manifold su geometrie complesse
    #      rimuoviamo facce duplicate anche qui
    mesh = repair_non_manifold(mesh)

    # 8 — fix normali finale + decimazione solo se watertight
    mesh = fix_normals(mesh)

    if is_watertight(mesh) and mesh.n_points > 100:
        decimated = mesh.decimate_pro(DECIMATE_FRACTION)
        decimated = decimated.triangulate().clean()
        decimated = fix_normals(decimated)
        if is_watertight(decimated):
            mesh = decimated

    # 9 — clean finale + report
    mesh = mesh.clean()

    watertight = is_watertight(mesh)
    if not watertight:
        bp = _count_boundary_pts(mesh)
        nm_pts = 0
        try:
            nm = mesh.extract_feature_edges(
                boundary_edges=False, non_manifold_edges=True,
                feature_edges=False,  manifold_edges=False)
            nm_pts = int(nm.n_points)
        except Exception:
            pass
        cause = "non-manifold edges" if (bp == 0 and nm_pts > 0) else "boundary edges aperte"
        if bp == 0 and nm_pts == 0:
            cause = "causa sconosciuta (volume negativo o degenere)"
        print(f"  [WARN] {sid}: NON watertight ({cause}) "
              f"boundary_pts={bp}, nm_pts={nm_pts} — salvata comunque")
    else:
        try:
            vol = mesh.volume
            sign = "OK" if vol > 0 else "NEGATIVO (normali invertite?)"
            print(f"  [OK-watertight] {sid} | vol={vol:.1f} mm³ [{sign}]")
        except Exception:
            print(f"  [OK-watertight] {sid}")

    return mesh


# ======================================================
# PROCESSING
# ======================================================
def process_mask(mask_path: str, out_dir: str):
    sid = extract_id(mask_path)
    vol, hdr = nrrd.read(mask_path)
    origin, M = nrrd_affine_from_header(hdr)

    vol  = (vol > 0).astype(np.uint8)
    mesh = polydata_from_binary_mask(vol, origin, M)
    mesh = clean_surface(mesh, sid=sid)

    out_path = os.path.join(out_dir, f"{sid}.vtk")
    mesh.save(out_path)
    print(f"[SAVED] {sid} | pts={mesh.n_points} | cells={mesh.n_cells}")


# ======================================================
# MAIN
# ======================================================
if __name__ == "__main__":
    print("=" * 55)
    print("  Mask -> Mesh  (con chiusura robusta)")
    print("=" * 55)

    print("\n[AORTA]")
    for f in sorted(glob.glob(os.path.join(AORTA_MASK_DIR, AORTA_PATTERN))):
        try:
            process_mask(f, AORTA_OUT)
        except Exception as e:
            print(f"[SKIP][AORTA] {os.path.basename(f)}: {e}")

    print("\n[RCA]")
    for f in sorted(glob.glob(os.path.join(RCA_MASK_DIR, RCA_PATTERN))):
        try:
            process_mask(f, RCA_OUT)
        except Exception as e:
            print(f"[SKIP][RCA] {os.path.basename(f)}: {e}")

    print("\n[DONE]")